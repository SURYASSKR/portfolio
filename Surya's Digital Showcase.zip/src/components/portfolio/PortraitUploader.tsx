import { useEffect, useRef, useState } from "react";
import { Camera } from "lucide-react";

const STORAGE_KEY = "portfolio:portrait";
const MAX_DIM = 800;
const QUALITY = 0.82;

async function compressImage(file: File): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image();
    i.onload = () => resolve(i);
    i.onerror = reject;
    i.src = dataUrl;
  });

  const scale = Math.min(1, MAX_DIM / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, w, h);

  // Prefer webp for smaller payload; fall back to jpeg.
  const webp = canvas.toDataURL("image/webp", QUALITY);
  if (webp.startsWith("data:image/webp")) return webp;
  return canvas.toDataURL("image/jpeg", QUALITY);
}

export function PortraitUploader({
  defaultSrc,
  alt,
}: {
  defaultSrc: string;
  alt: string;
}) {
  const [src, setSrc] = useState<string>(defaultSrc);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) setSrc(saved);
    } catch {}
  }, []);

  const onPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!/^image\/(jpe?g|png|webp)$/i.test(file.type)) return;
    setBusy(true);
    try {
      const compressed = await compressImage(file);
      setSrc(compressed);
      try {
        localStorage.setItem(STORAGE_KEY, compressed);
      } catch {
        // Storage full — retry with smaller quality
        try {
          const canvas = document.createElement("canvas");
          const img = new Image();
          await new Promise((res) => {
            img.onload = res;
            img.src = compressed;
          });
          const s = Math.min(1, 512 / Math.max(img.width, img.height));
          canvas.width = Math.round(img.width * s);
          canvas.height = Math.round(img.height * s);
          canvas.getContext("2d")?.drawImage(img, 0, 0, canvas.width, canvas.height);
          const fallback = canvas.toDataURL("image/jpeg", 0.7);
          localStorage.setItem(STORAGE_KEY, fallback);
          setSrc(fallback);
        } catch {}
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="relative w-full aspect-[4/5] overflow-hidden group">
      <img
        src={src}
        alt={alt}
        width={800}
        height={1000}
        className="w-full h-full object-cover transition-all duration-700"
      />

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png,image/webp"
        className="hidden"
        onChange={onPick}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={busy}
        title="Change Profile Photo"
        aria-label="Change Profile Photo"
        className="absolute bottom-3 right-3 h-9 w-9 rounded-full bg-background/90 backdrop-blur border border-border flex items-center justify-center text-foreground shadow-sm hover:bg-foreground hover:text-background transition-colors disabled:opacity-60"
      >
        <Camera className={`h-4 w-4 ${busy ? "animate-pulse" : ""}`} />
        <span className="pointer-events-none absolute bottom-full mb-2 right-0 whitespace-nowrap font-mono text-[9px] uppercase tracking-widest bg-foreground text-background px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity">
          {busy ? "Compressing…" : "Change Profile Photo"}
        </span>
      </button>
    </div>
  );
}
