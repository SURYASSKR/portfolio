import { Link } from "@tanstack/react-router";
import { MoreVertical, ExternalLink, Code2, Play, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import type { Project } from "@/lib/projects.functions";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";

type Props = {
  project: Project;
  color: string;
  isAdmin: boolean;
  onEdit?: () => void;
  onDuplicate?: () => void;
  onDelete?: () => void;
};

export function ProjectCard({
  project: p,
  color,
  isAdmin,
  onEdit,
  onDuplicate,
  onDelete,
}: Props) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ y: -6 }}
      className="group relative flex h-full flex-col rounded-3xl overflow-hidden bg-surface border border-border shadow-sm transition-shadow duration-300 hover:shadow-xl"
    >
      <div className="aspect-[16/10] overflow-hidden bg-muted relative">
        {p.cover_url ? (
          <img
            src={p.cover_url}
            alt={p.title}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full grid place-items-center text-muted-foreground text-sm">
            No image
          </div>
        )}
        <div
          className="absolute top-4 left-4 px-3 py-1.5 rounded-full text-[11px] font-semibold text-white shadow-sm"
          style={{ background: color }}
        >
          {p.category}
        </div>
        {p.featured && (
          <div className="absolute top-4 right-4 px-2.5 py-1 rounded-full text-[10px] font-semibold bg-background/90 border border-border">
            ★ Featured
          </div>
        )}
        {isAdmin && (
          <div className="absolute bottom-3 right-3 flex items-center gap-1.5">
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onEdit?.();
              }}
              className="rounded-full bg-background/95 border border-border px-3 py-1.5 text-[11px] font-semibold shadow-sm hover:bg-foreground hover:text-background transition-colors"
            >
              Edit
            </button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  onClick={(e) => e.stopPropagation()}
                  className="rounded-full bg-background/95 border border-border p-1.5 shadow-sm hover:bg-foreground hover:text-background transition-colors"
                  aria-label="Project actions"
                >
                  <MoreVertical className="size-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={onEdit}>Edit</DropdownMenuItem>
                <DropdownMenuItem onClick={onDuplicate}>Duplicate</DropdownMenuItem>
                <DropdownMenuItem
                  onClick={onDelete}
                  className="text-destructive focus:text-destructive"
                >
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}

      </div>

      <div className="flex-1 flex flex-col p-6">
        <h3 className="font-heading text-xl md:text-2xl font-semibold tracking-tight group-hover:text-[#4285F4] transition-colors">
          {p.title}
        </h3>
        {(p.tagline || p.problem) && (
          <p className="mt-2 text-sm text-muted-foreground leading-relaxed line-clamp-2">
            {p.tagline || p.problem}
          </p>
        )}

        {p.technologies.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-1.5">
            {p.technologies.slice(0, 5).map((t) => (
              <span
                key={t}
                className="text-[10px] font-medium px-2 py-1 rounded-full bg-background border border-border"
              >
                {t}
              </span>
            ))}
            {p.technologies.length > 5 && (
              <span className="text-[10px] font-medium px-2 py-1 rounded-full bg-background border border-border">
                +{p.technologies.length - 5}
              </span>
            )}
          </div>
        )}

        {p.metrics.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {p.metrics.slice(0, 3).map((m) => (
              <span
                key={m}
                className="text-[11px] font-semibold px-2.5 py-1 rounded-full text-white"
                style={{ background: color }}
              >
                {m}
              </span>
            ))}
          </div>
        )}

        <div className="mt-auto pt-6 flex flex-wrap items-center gap-2">
          <Link
            to="/projects/$slug"
            params={{ slug: p.slug }}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-foreground hover:text-[#4285F4] transition-colors"
          >
            View details <ArrowRight className="size-3.5" />
          </Link>
          <div className="ml-auto flex items-center gap-1">
            {p.live_url && (
              <a
                href={p.live_url}
                target="_blank"
                rel="noreferrer"
                aria-label="Live demo"
                className="p-2 rounded-full border border-border hover:bg-foreground hover:text-background transition-colors"
              >
                <ExternalLink className="size-3.5" />
              </a>
            )}
            {p.github_url && (
              <a
                href={p.github_url}
                target="_blank"
                rel="noreferrer"
                aria-label="GitHub"
                className="p-2 rounded-full border border-border hover:bg-foreground hover:text-background transition-colors"
              >
                <Code2 className="size-3.5" />
              </a>
            )}
            {p.video_url && (
              <a
                href={p.video_url}
                target="_blank"
                rel="noreferrer"
                aria-label="Video"
                className="p-2 rounded-full border border-border hover:bg-foreground hover:text-background transition-colors"
              >
                <Play className="size-3.5" />
              </a>
            )}
          </div>
        </div>
      </div>
    </motion.article>
  );
}
