import type { ReactNode } from "react";

export function Marquee({
  items,
  className,
}: {
  items: ReactNode[];
  className?: string;
}) {
  return (
    <div className={`relative overflow-hidden ${className ?? ""}`}>
      <div className="flex w-max animate-marquee gap-12 py-4">
        {[...items, ...items].map((it, i) => (
          <span
            key={i}
            className="font-mono text-[11px] uppercase tracking-[0.3em] text-foreground/60 flex items-center gap-12"
          >
            {it}
            <span className="size-1 rounded-full bg-accent" />
          </span>
        ))}
      </div>
    </div>
  );
}
