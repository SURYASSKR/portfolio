import { useEffect, useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { X, Upload, Plus, Loader2, Image as ImageIcon } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  createProject,
  updateProject,
  uploadProjectCover,
  type Project,
} from "@/lib/projects.functions";
import {
  PROJECT_CATEGORIES,
  PROJECT_STATUSES,
  COMMON_TECHNOLOGIES,
} from "@/lib/project-constants";


type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  project?: Project | null;
};

type FormState = {
  title: string;
  tagline: string;
  category: string;
  problem: string;
  solution: string;
  impact: string;
  cover_path: string;
  cover_url: string | null;
  gallery: { path: string; url: string }[];
  live_url: string;
  github_url: string;
  case_study_url: string;
  video_url: string;
  technologies: string[];
  metrics: string[];
  status: "completed" | "in_progress" | "planned";
  featured: boolean;
  sort_order: number;
};

const empty: FormState = {
  title: "",
  tagline: "",
  category: PROJECT_CATEGORIES[0],
  problem: "",
  solution: "",
  impact: "",
  cover_path: "",
  cover_url: null,
  gallery: [],
  live_url: "",
  github_url: "",
  case_study_url: "",
  video_url: "",
  technologies: [],
  metrics: [],
  status: "completed",
  featured: false,
  sort_order: 0,
};

export function ProjectFormDialog({ open, onOpenChange, project }: Props) {
  const qc = useQueryClient();
  const doCreate = useServerFn(createProject);
  const doUpdate = useServerFn(updateProject);
  const doUpload = useServerFn(uploadProjectCover);

  const [state, setState] = useState<FormState>(empty);
  const [techInput, setTechInput] = useState("");
  const [metricInput, setMetricInput] = useState("");
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const galleryRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!open) return;
    if (project) {
      setState({
        title: project.title,
        tagline: project.tagline,
        category: project.category,
        problem: project.problem,
        solution: project.solution,
        impact: project.impact,
        cover_path: project.cover_path,
        cover_url: project.cover_url,
        gallery: (project.gallery_paths ?? []).map((p, i) => ({
          path: p,
          url: (project.gallery_urls ?? [])[i] ?? "",
        })),
        live_url: project.live_url,
        github_url: project.github_url,
        case_study_url: project.case_study_url,
        video_url: project.video_url,
        technologies: project.technologies,
        metrics: project.metrics,
        status: project.status,
        featured: project.featured,
        sort_order: project.sort_order,
      });
    } else {
      setState(empty);
    }
    setTechInput("");
    setMetricInput("");
  }, [open, project]);

  const mutation = useMutation({
    mutationFn: async () => {
      if (!state.title.trim()) throw new Error("Project name is required");
      if (!state.category.trim()) throw new Error("Category is required");
      if (!state.problem.trim() && !state.solution.trim() && !state.impact.trim())
        throw new Error("Please add at least one description field");
      if (!state.cover_path) throw new Error("Cover image is required");
      const payload = {
        title: state.title.trim(),
        tagline: state.tagline.trim(),
        category: state.category,
        problem: state.problem.trim(),
        solution: state.solution.trim(),
        impact: state.impact.trim(),
        cover_path: state.cover_path,
        gallery_paths: state.gallery.map((g) => g.path),
        live_url: state.live_url.trim(),
        github_url: state.github_url.trim(),
        case_study_url: state.case_study_url.trim(),
        video_url: state.video_url.trim(),
        technologies: state.technologies,
        metrics: state.metrics,
        status: state.status,
        featured: state.featured,
        sort_order: state.sort_order,
      };
      if (project) {
        await doUpdate({ data: { id: project.id, patch: payload } });
      } else {
        await doCreate({ data: payload });
      }
    },
    onSuccess: () => {
      toast.success(project ? "Project updated" : "Project created");
      qc.invalidateQueries({ queryKey: ["projects"] });
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function handleFile(file: File, target: "cover" | "gallery" = "cover") {
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
      toast.error("Only JPG, PNG, or WEBP images");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      toast.error("Image must be under 8 MB");
      return;
    }
    if (target === "gallery" && state.gallery.length >= 12) {
      toast.error("Maximum 12 additional images");
      return;
    }
    setUploading(true);
    try {
      const buf = await file.arrayBuffer();
      let binary = "";
      const bytes = new Uint8Array(buf);
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
      }
      const base64 = btoa(binary);
      const ext = file.type === "image/jpeg" ? "jpg" : file.type === "image/png" ? "png" : "webp";
      const res = await doUpload({
        data: { base64, contentType: file.type as any, ext: ext as any },
      });
      if (target === "gallery") {
        setState((s) => ({ ...s, gallery: [...s.gallery, { path: res.path, url: res.url }] }));
      } else {
        setState((s) => ({ ...s, cover_path: res.path, cover_url: res.url }));
      }
      toast.success("Image uploaded");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  }


  function addTech(t: string) {
    const v = t.trim();
    if (!v) return;
    if (state.technologies.includes(v)) return;
    setState((s) => ({ ...s, technologies: [...s.technologies, v] }));
    setTechInput("");
  }
  function removeTech(t: string) {
    setState((s) => ({ ...s, technologies: s.technologies.filter((x) => x !== t) }));
  }
  function addMetric() {
    const v = metricInput.trim();
    if (!v) return;
    setState((s) => ({ ...s, metrics: [...s.metrics, v] }));
    setMetricInput("");
  }
  function removeMetric(i: number) {
    setState((s) => ({ ...s, metrics: s.metrics.filter((_, idx) => idx !== i) }));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{project ? "Edit project" : "Add project"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 pt-2">
          {/* Basic */}
          <section className="space-y-4">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Basic information
            </h3>
            <div className="grid gap-2">
              <Label>Project name *</Label>
              <Input
                value={state.title}
                onChange={(e) => setState({ ...state, title: e.target.value })}
                placeholder="Global Ledger Reconciliation"
              />
            </div>
            <div className="grid gap-2">
              <Label>Short tagline</Label>
              <Input
                value={state.tagline}
                onChange={(e) => setState({ ...state, tagline: e.target.value })}
                placeholder="Self-healing pipeline for regional ledgers"
              />
            </div>
            <div className="grid gap-2">
              <Label>Category *</Label>
              <Select
                value={state.category}
                onValueChange={(v) => setState({ ...state, category: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PROJECT_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </section>

          {/* Description */}
          <section className="space-y-4">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Description
            </h3>
            <div className="grid gap-2">
              <Label>Problem statement</Label>
              <Textarea
                rows={3}
                value={state.problem}
                onChange={(e) => setState({ ...state, problem: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label>Solution</Label>
              <Textarea
                rows={3}
                value={state.solution}
                onChange={(e) => setState({ ...state, solution: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label>Business impact</Label>
              <Textarea
                rows={3}
                value={state.impact}
                onChange={(e) => setState({ ...state, impact: e.target.value })}
              />
            </div>
          </section>

          {/* Cover image */}
          <section className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Cover image *
            </h3>
            <div
              className={`border-2 border-dashed rounded-2xl p-6 text-center transition-colors ${
                dragOver ? "border-primary bg-primary/5" : "border-border"
              }`}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                const f = e.dataTransfer.files?.[0];
                if (f) handleFile(f);
              }}
            >
              {state.cover_url ? (
                <div className="space-y-3">
                  <img
                    src={state.cover_url}
                    alt="Cover preview"
                    className="mx-auto max-h-56 rounded-xl object-cover"
                  />
                  <div className="flex justify-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => fileRef.current?.click()}
                      disabled={uploading}
                    >
                      Replace
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() =>
                        setState((s) => ({ ...s, cover_path: "", cover_url: null }))
                      }
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-3 py-4">
                  <ImageIcon className="size-8 text-muted-foreground" />
                  <div className="text-sm">
                    Drag & drop an image here, or{" "}
                    <button
                      type="button"
                      className="text-primary underline"
                      onClick={() => fileRef.current?.click()}
                    >
                      browse
                    </button>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    JPG, PNG or WEBP · max 8 MB
                  </div>
                </div>
              )}
              {uploading && (
                <div className="mt-3 flex items-center justify-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="size-4 animate-spin" /> Uploading…
                </div>
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleFile(f);
                  e.currentTarget.value = "";
                }}
              />
            </div>
          </section>

          {/* Additional images */}
          <section className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Additional images
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {state.gallery.map((g, i) => (
                <div
                  key={g.path}
                  className="relative group rounded-xl overflow-hidden border border-border bg-surface"
                >
                  {g.url ? (
                    <img
                      src={g.url}
                      alt={`Project image ${i + 1}`}
                      className="h-28 w-full object-cover"
                    />
                  ) : (
                    <div className="h-28 w-full grid place-items-center text-xs text-muted-foreground">
                      Image {i + 1}
                    </div>
                  )}
                  <button
                    type="button"
                    aria-label="Remove image"
                    onClick={() =>
                      setState((s) => ({
                        ...s,
                        gallery: s.gallery.filter((_, idx) => idx !== i),
                      }))
                    }
                    className="absolute top-1.5 right-1.5 rounded-full bg-background/90 border border-border p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="size-3.5" />
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => galleryRef.current?.click()}
                disabled={uploading || state.gallery.length >= 12}
                className="h-28 rounded-xl border-2 border-dashed border-border flex flex-col items-center justify-center gap-1 text-muted-foreground hover:border-primary hover:text-primary transition-colors disabled:opacity-50"
              >
                {uploading ? (
                  <Loader2 className="size-5 animate-spin" />
                ) : (
                  <Plus className="size-5" />
                )}
                <span className="text-xs">Add image</span>
              </button>
            </div>
            <p className="text-xs text-muted-foreground">
              Click “Add image” for each extra screenshot · up to 12 · JPG, PNG or WEBP
            </p>
            <input
              ref={galleryRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              multiple
              className="hidden"
              onChange={async (e) => {
                const files = Array.from(e.target.files ?? []);
                e.currentTarget.value = "";
                for (const f of files) await handleFile(f, "gallery");
              }}
            />
          </section>

          {/* Links */}
          <section className="space-y-4">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Project links
            </h3>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label>Live demo URL</Label>
                <Input
                  value={state.live_url}
                  onChange={(e) => setState({ ...state, live_url: e.target.value })}
                  placeholder="https://…"
                />
              </div>
              <div className="grid gap-2">
                <Label>GitHub URL</Label>
                <Input
                  value={state.github_url}
                  onChange={(e) => setState({ ...state, github_url: e.target.value })}
                  placeholder="https://github.com/…"
                />
              </div>
              <div className="grid gap-2">
                <Label>Case study URL</Label>
                <Input
                  value={state.case_study_url}
                  onChange={(e) =>
                    setState({ ...state, case_study_url: e.target.value })
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label>Video URL</Label>
                <Input
                  value={state.video_url}
                  onChange={(e) => setState({ ...state, video_url: e.target.value })}
                />
              </div>
            </div>
          </section>

          {/* Technologies */}
          <section className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Technologies
            </h3>
            <div className="flex flex-wrap gap-2">
              {state.technologies.map((t) => (
                <span
                  key={t}
                  className="inline-flex items-center gap-1 rounded-full bg-surface border border-border px-3 py-1 text-xs"
                >
                  {t}
                  <button
                    type="button"
                    onClick={() => removeTech(t)}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="size-3" />
                  </button>
                </span>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="Add a technology and press Enter"
                value={techInput}
                onChange={(e) => setTechInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addTech(techInput);
                  }
                }}
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => addTech(techInput)}
              >
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_TECHNOLOGIES.filter((t) => !state.technologies.includes(t)).map(
                (t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => addTech(t)}
                    className="text-xs rounded-full border border-dashed border-border px-2.5 py-1 text-muted-foreground hover:text-foreground hover:border-foreground/50"
                  >
                    + {t}
                  </button>
                ),
              )}
            </div>
          </section>

          {/* Metrics */}
          <section className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Business metrics
            </h3>
            <div className="space-y-2">
              {state.metrics.map((m, i) => (
                <div
                  key={`${m}-${i}`}
                  className="flex items-center gap-2 rounded-lg border border-border px-3 py-2"
                >
                  <span className="flex-1 text-sm">{m}</span>
                  <button
                    type="button"
                    onClick={() => removeMetric(i)}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="size-4" />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="e.g. 95% Accuracy, $1.2M Savings"
                value={metricInput}
                onChange={(e) => setMetricInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addMetric();
                  }
                }}
              />
              <Button type="button" variant="outline" onClick={addMetric}>
                <Plus className="size-4" />
              </Button>
            </div>
          </section>

          {/* Status + featured + order */}
          <section className="grid sm:grid-cols-3 gap-4">
            <div className="grid gap-2">
              <Label>Status</Label>
              <Select
                value={state.status}
                onValueChange={(v) => setState({ ...state, status: v as any })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PROJECT_STATUSES.map((s) => (
                    <SelectItem key={s.value} value={s.value}>
                      {s.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Display order</Label>
              <Input
                type="number"
                min={0}
                value={state.sort_order}
                onChange={(e) =>
                  setState({ ...state, sort_order: Number(e.target.value) || 0 })
                }
              />
            </div>
            <div className="flex items-end">
              <label className="flex items-center gap-2 text-sm">
                <Checkbox
                  checked={state.featured}
                  onCheckedChange={(v) => setState({ ...state, featured: v === true })}
                />
                Show as featured
              </label>
            </div>
          </section>
        </div>

        <DialogFooter className="pt-4">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={() => mutation.mutate()} disabled={mutation.isPending || uploading}>
            {mutation.isPending ? (
              <>
                <Loader2 className="size-4 mr-2 animate-spin" /> Saving…
              </>
            ) : project ? (
              "Save changes"
            ) : (
              <>
                <Upload className="size-4 mr-2" /> Create project
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
