import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export function RotatingRole({ roles }: { roles: string[] }) {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setI((p) => (p + 1) % roles.length), 2400);
    return () => clearInterval(id);
  }, [roles.length]);

  return (
    <div className="h-8 md:h-10 overflow-hidden font-mono text-xl md:text-2xl uppercase tracking-tight text-foreground/60">
      <AnimatePresence mode="wait">
        <motion.span
          key={i}
          initial={{ y: 24, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -24, opacity: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="block"
        >
          {roles[i]}
        </motion.span>
      </AnimatePresence>
    </div>
  );
}
