import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { updateStat, type Stat } from "@/lib/stats.functions";

export function EditStatDialog({
  stat,
  open,
  onOpenChange,
}: {
  stat: Stat | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const qc = useQueryClient();
  const doUpdate = useServerFn(updateStat);
  const [value, setValue] = useState("");
  const [suffix, setSuffix] = useState("");

  useEffect(() => {
    if (stat) {
      setValue(stat.value);
      setSuffix(stat.suffix);
    }
  }, [stat]);

  const mutation = useMutation({
    mutationFn: () =>
      doUpdate({ data: { id: stat!.id, value: value.trim(), suffix: suffix.trim() } }),
    onSuccess: () => {
      toast.success(`${stat?.label} updated`);
      qc.invalidateQueries({ queryKey: ["stats"] });
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function onSave() {
    if (!/^\d+(\.\d+)?$/.test(value.trim())) {
      toast.error("Value must be numeric");
      return;
    }
    mutation.mutate();
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-background border-border">
        <DialogHeader>
          <DialogTitle className="font-mono text-xs uppercase tracking-widest text-accent">
            Edit {stat?.label}
          </DialogTitle>
        </DialogHeader>
        {stat && (
          <div className="space-y-4">
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-widest opacity-60 mb-1">
                Value
              </label>
              <input
                value={value}
                onChange={(e) => setValue(e.target.value)}
                inputMode="decimal"
                className="w-full bg-transparent border border-border px-3 py-2 font-mono focus:outline-none focus:border-accent"
              />
            </div>
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-widest opacity-60 mb-1">
                Suffix
              </label>
              <input
                value={suffix}
                onChange={(e) => setSuffix(e.target.value)}
                className="w-full bg-transparent border border-border px-3 py-2 font-mono focus:outline-none focus:border-accent"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => onOpenChange(false)}
                className="font-mono text-[10px] uppercase tracking-widest border border-border px-4 py-2 hover:bg-foreground hover:text-background"
              >
                Cancel
              </button>
              <button
                onClick={onSave}
                disabled={mutation.isPending}
                className="font-mono text-[10px] uppercase tracking-widest bg-foreground text-background px-4 py-2 hover:bg-accent transition-colors disabled:opacity-50"
              >
                {mutation.isPending ? "Saving..." : "Save"}
              </button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
