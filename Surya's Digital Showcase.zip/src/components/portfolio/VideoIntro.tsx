import { useCallback, useEffect, useRef, useState } from "react";
import {
  Play,
  Pause,
  Loader2,
  Upload,
  Trash2,
  RefreshCw,
  AlertCircle,
  ImagePlus,
  ImageOff,
  Pencil,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Film,
} from "lucide-react";
import { createPortal } from "react-dom";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import {
  getIntroPoster,
  getIntroVideo,
  createIntroVideoUploadUrl,
  deleteIntroVideo,
  uploadIntroPoster,
  deleteIntroPoster,
} from "@/lib/intro-media.functions";

const ACCEPT = "video/mp4,.mp4";
const MAX_MB = 200;

const POSTER_ACCEPT = "image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp";
const POSTER_MAX_MB = 10;

type StoredVideo = { name: string; url: string };

function formatTime(secs: number) {
  if (!isFinite(secs) || secs < 0) return "0:00";
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

async function fileToBase64(file: File): Promise<string> {
  const buf = await file.arrayBuffer();
  let binary = "";
  const bytes = new Uint8Array(buf);
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}


export function VideoIntro({
  label: _label,
  name = "Surya Kiran",
  isAdmin = false,
  portfolioSlug,
  duration: _duration,
}: {
  poster?: string;
  src?: string;
  label?: string;
  name?: string;
  isAdmin?: boolean;
  portfolioSlug: string;
  duration?: string;
}) {

  const [video, setVideo] = useState<StoredVideo | null>(null);
  const [loadingInitial, setLoadingInitial] = useState(true);
  const [videoReady, setVideoReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [videoDuration, setVideoDuration] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [hovering, setHovering] = useState(false);

  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const [customPoster, setCustomPoster] = useState<string | null>(null);
  const [posterUploading, setPosterUploading] = useState(false);
  const [posterError, setPosterError] = useState<string | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);
  const posterInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async () => {
    try {
      const v = await getIntroVideo({ data: { portfolioSlug } });
      setVideo(v);
    } catch (err) {
      console.error("Failed to load intro video", err);
      setVideo(null);
    } finally {
      setLoadingInitial(false);
    }
  }, [portfolioSlug]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  useEffect(() => {
    let cancelled = false;
    getIntroPoster({ data: { portfolioSlug } }).then((url) => {
      if (!cancelled) setCustomPoster(url);
    });
    return () => {
      cancelled = true;
    };
  }, [portfolioSlug]);


  // Reset ready state when video source changes
  useEffect(() => {
    setVideoReady(false);
    setPlaying(false);
    setCurrentTime(0);
    setVideoDuration(0);
  }, [video?.url]);

  // Fullscreen tracking
  useEffect(() => {
    const onFsChange = () => setIsFullscreen(document.fullscreenElement === containerRef.current);
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  // Close admin menu on outside click / Esc
  useEffect(() => {
    if (!menuOpen) return;
    const onDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [menuOpen]);

  // Keyboard controls when container is focused/hovered
  useEffect(() => {
    if (!video) return;
    const onKey = (e: KeyboardEvent) => {
      const v = videoRef.current;
      if (!v) return;
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
      if (!containerRef.current?.matches(":hover") && document.fullscreenElement !== containerRef.current) return;
      switch (e.key) {
        case " ":
        case "k":
          e.preventDefault();
          if (v.paused) void v.play();
          else v.pause();
          break;
        case "ArrowRight":
          e.preventDefault();
          v.currentTime = Math.min(v.duration || 0, v.currentTime + 5);
          break;
        case "ArrowLeft":
          e.preventDefault();
          v.currentTime = Math.max(0, v.currentTime - 5);
          break;
        case "ArrowUp":
          e.preventDefault();
          v.volume = Math.min(1, v.volume + 0.05);
          setVolume(v.volume);
          break;
        case "ArrowDown":
          e.preventDefault();
          v.volume = Math.max(0, v.volume - 0.05);
          setVolume(v.volume);
          break;
        case "m":
          v.muted = !v.muted;
          setMuted(v.muted);
          break;
        case "f":
          void toggleFullscreen();
          break;
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [video]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) void v.play();
    else v.pause();
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  };

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    if (document.fullscreenElement === containerRef.current) {
      await document.exitFullscreen();
    } else {
      await containerRef.current.requestFullscreen();
    }
  };

  const onSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const v = videoRef.current;
    if (!v || !videoDuration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    v.currentTime = Math.max(0, Math.min(videoDuration, pct * videoDuration));
  };

  // ---------- Upload / replace / delete ----------
  const onPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (file.type !== "video/mp4" && !file.name.toLowerCase().endsWith(".mp4")) {
      setUploadError("Only MP4 (.mp4) video files are allowed.");
      return;
    }
    if (file.size > MAX_MB * 1024 * 1024) {
      setUploadError(`Video is too large. Max ${MAX_MB} MB.`);
      return;
    }
    setUploadError(null);
    setUploading(true);
    setProgress(10);
    try {
      const { bucket, path, token } = await createIntroVideoUploadUrl();
      setProgress(40);
      const { error } = await supabase.storage
        .from(bucket)
        .uploadToSignedUrl(path, token, file, { contentType: "video/mp4" });
      if (error) throw error;
      setProgress(85);
      await refresh();
      setProgress(100);
    } catch (err) {
      console.error(err);
      setUploadError(err instanceof Error ? err.message : "Video upload failed.");
    } finally {
      setUploading(false);
      setTimeout(() => setProgress(0), 500);
    }
  };

  const doDelete = async () => {
    setDeleting(true);
    try {
      await deleteIntroVideo();
      setVideo(null);
      setConfirmDelete(false);
    } catch (err) {
      console.error(err);
      setUploadError(err instanceof Error ? err.message : "Failed to delete video.");
    } finally {
      setDeleting(false);
    }
  };


  const onPickPoster = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const validType =
      file.type === "image/jpeg" ||
      file.type === "image/png" ||
      file.type === "image/webp" ||
      /\.(jpg|jpeg|png|webp)$/i.test(file.name);
    if (!validType) {
      setPosterError("Only JPG, PNG, or WebP images are allowed.");
      return;
    }
    if (file.size > POSTER_MAX_MB * 1024 * 1024) {
      setPosterError(`Poster image is too large. Max ${POSTER_MAX_MB} MB.`);
      return;
    }
    setPosterError(null);
    void uploadPoster(file);
  };

  const uploadPoster = async (file: File) => {
    setPosterUploading(true);
    try {
      const contentType =
        file.type === "image/png" || file.type === "image/webp" ? file.type : "image/jpeg";
      const base64 = await fileToBase64(file);
      await uploadIntroPoster({ data: { base64, contentType } });
      const url = await getIntroPoster({ data: { portfolioSlug } });
      setCustomPoster(url);
    } catch (err) {
      console.error(err);
      setPosterError(err instanceof Error ? err.message : "Poster upload failed.");
    } finally {
      setPosterUploading(false);
    }
  };

  const removePoster = async () => {
    setPosterUploading(true);
    try {
      await deleteIntroPoster();
      setCustomPoster(null);
    } catch (err) {
      console.error(err);
      setPosterError(err instanceof Error ? err.message : "Failed to remove poster.");
    } finally {
      setPosterUploading(false);
    }
  };


  const hasVideo = !!video;
  const showOverlays = hovering || !playing;

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-video overflow-hidden bg-black group rounded-[inherit]"
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => {
        setHovering(false);
        setMenuOpen(false);
      }}
    >
      {/* Initial load */}
      {loadingInitial && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black">
          <Loader2 className="h-8 w-8 text-white/70 animate-spin" />
        </div>
      )}

      {/* ------- ADMIN UPLOAD PLACEHOLDER ------- */}
      {!loadingInitial && !hasVideo && isAdmin && (
        <button
          type="button"
          onClick={() => !uploading && inputRef.current?.click()}
          disabled={uploading}
          aria-label="Upload introduction MP4 video"
          className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-gradient-to-br from-neutral-900 to-neutral-950 text-white/90 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-white/50 transition-colors group/upload disabled:cursor-wait"
        >
          <div className="h-20 w-20 rounded-full bg-white/10 group-hover/upload:bg-white/20 flex items-center justify-center transition-colors">
            {uploading ? (
              <Loader2 className="h-9 w-9 animate-spin" />
            ) : (
              <Upload className="h-9 w-9" />
            )}
          </div>
          <div className="text-center px-6">
            <div className="text-base md:text-lg font-semibold">
              {uploading ? "Uploading video…" : "Upload Introduction Video"}
            </div>
            <div className="text-xs md:text-sm text-white/60 mt-1">
              {uploading ? `${progress}%` : "MP4 only · up to 200 MB"}
            </div>
          </div>
          {uploading && (
            <div className="absolute bottom-0 inset-x-0 h-1 bg-white/10">
              <div
                className="h-full bg-[#e50914] transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          )}
          {uploadError && (
            <div className="absolute top-4 inset-x-4 mx-auto max-w-md inline-flex items-center gap-2 px-3 py-2 rounded-md bg-red-600/95 text-white text-xs font-medium shadow">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span className="truncate">{uploadError}</span>
            </div>
          )}
        </button>
      )}

      {/* ------- VISITOR EMPTY STATE ------- */}
      {!loadingInitial && !hasVideo && !isAdmin && (
        <div
          className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 text-white/80"
          aria-label="Introduction video coming soon"
        >
          {customPoster ? (
            <img
              src={customPoster}
              alt={`${name} introduction poster`}
              className="absolute inset-0 w-full h-full object-cover"
            />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-neutral-900 to-neutral-950" />
          )}
          <div className="absolute inset-0 bg-black/50" />
          <div className="relative flex flex-col items-center gap-3">
            <div className="h-16 w-16 rounded-full bg-white/10 flex items-center justify-center">
              <Film className="h-7 w-7" />
            </div>
            <div className="text-sm md:text-base font-medium">Introduction video coming soon</div>
          </div>
        </div>
      )}

      {/* ------- VIDEO PLAYER ------- */}
      {!loadingInitial && hasVideo && (
        <>
          {!videoReady && (
            <div className="absolute inset-0 z-20 flex items-center justify-center bg-black">
              <Loader2 className="h-8 w-8 text-white/70 animate-spin" />
            </div>
          )}
          <video
            ref={videoRef}
            src={video!.url}
            poster={customPoster ?? undefined}
            preload="metadata"
            playsInline
            onLoadedMetadata={(e) => {
              setVideoDuration(e.currentTarget.duration);
              setVideoReady(true);
              setVolume(e.currentTarget.volume);
              setMuted(e.currentTarget.muted);
            }}
            onCanPlay={() => setVideoReady(true)}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            onEnded={() => setPlaying(false)}
            onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
            onVolumeChange={(e) => {
              setVolume(e.currentTarget.volume);
              setMuted(e.currentTarget.muted);
            }}
            onClick={togglePlay}
            className="absolute inset-0 w-full h-full object-cover bg-black cursor-pointer"
          />

          {/* Center play/pause — visible when paused or hovering */}
          <button
            type="button"
            onClick={togglePlay}
            aria-label={playing ? "Pause video" : "Play video"}
            className={cn(
              "absolute inset-0 m-auto h-16 w-16 md:h-20 md:w-20 rounded-full bg-black/50 hover:bg-black/70 backdrop-blur text-white flex items-center justify-center transition-opacity duration-200 z-20",
              showOverlays ? "opacity-100" : "opacity-0 pointer-events-none",
            )}
          >
            {playing ? (
              <Pause className="h-8 w-8 fill-current" />
            ) : (
              <Play className="h-8 w-8 ml-1 fill-current" />
            )}
          </button>

          {/* Bottom control bar */}
          <div
            className={cn(
              "absolute inset-x-0 bottom-0 z-20 px-3 md:px-4 pb-3 pt-8 bg-gradient-to-t from-black/80 via-black/40 to-transparent transition-opacity duration-200",
              hovering ? "opacity-100" : "opacity-0 pointer-events-none",
            )}
          >
            {/* Progress bar */}
            <div
              role="slider"
              aria-label="Seek"
              aria-valuemin={0}
              aria-valuemax={Math.round(videoDuration)}
              aria-valuenow={Math.round(currentTime)}
              onClick={onSeek}
              className="group/prog relative h-1.5 w-full rounded-full bg-white/25 cursor-pointer mb-2"
            >
              <div
                className="absolute inset-y-0 left-0 rounded-full bg-[#e50914] transition-[width] duration-100"
                style={{ width: videoDuration ? `${(currentTime / videoDuration) * 100}%` : "0%" }}
              />
              <div
                className="absolute top-1/2 -translate-y-1/2 h-3 w-3 rounded-full bg-[#e50914] shadow opacity-0 group-hover/prog:opacity-100 transition-opacity"
                style={{
                  left: videoDuration ? `calc(${(currentTime / videoDuration) * 100}% - 6px)` : "0",
                }}
              />
            </div>
            <div className="flex items-center gap-2 md:gap-3 text-white">
              <button
                type="button"
                onClick={togglePlay}
                aria-label={playing ? "Pause" : "Play"}
                className="h-8 w-8 flex items-center justify-center hover:bg-white/10 rounded-full transition-colors"
              >
                {playing ? <Pause className="h-4 w-4 fill-current" /> : <Play className="h-4 w-4 ml-0.5 fill-current" />}
              </button>
              <button
                type="button"
                onClick={toggleMute}
                aria-label={muted ? "Unmute" : "Mute"}
                className="h-8 w-8 flex items-center justify-center hover:bg-white/10 rounded-full transition-colors"
              >
                {muted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={muted ? 0 : volume}
                onChange={(e) => {
                  const v = videoRef.current;
                  if (!v) return;
                  const nv = parseFloat(e.target.value);
                  v.volume = nv;
                  v.muted = nv === 0;
                }}
                aria-label="Volume"
                className="hidden md:block w-20 accent-white"
              />
              <div className="text-[11px] md:text-xs tabular-nums text-white/90 ml-1">
                {formatTime(currentTime)} <span className="text-white/50">/ {formatTime(videoDuration)}</span>
              </div>
              <div className="ml-auto flex items-center gap-1">
                <button
                  type="button"
                  onClick={toggleFullscreen}
                  aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
                  className="h-8 w-8 flex items-center justify-center hover:bg-white/10 rounded-full transition-colors"
                >
                  {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
                </button>
              </div>
            </div>
          </div>

          {/* Admin pencil menu (top-right, hover only) */}
          {isAdmin && (
            <div
              ref={menuRef}
              className={cn(
                "absolute top-3 right-3 z-30 transition-opacity duration-200",
                hovering || menuOpen ? "opacity-100" : "opacity-0 pointer-events-none",
              )}
            >
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setMenuOpen((o) => !o);
                }}
                aria-label="Edit introduction video"
                aria-haspopup="menu"
                aria-expanded={menuOpen}
                className="h-9 w-9 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur text-white flex items-center justify-center border border-white/15 shadow transition-colors"
              >
                <Pencil className="h-4 w-4" />
              </button>
              {menuOpen && (
                <div
                  role="menu"
                  className="absolute right-0 mt-2 w-52 rounded-xl border border-border bg-background/95 backdrop-blur shadow-2xl overflow-hidden text-sm"
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      setMenuOpen(false);
                      inputRef.current?.click();
                    }}
                    disabled={uploading}
                    className="w-full flex items-center gap-2 px-3 py-2.5 text-left hover:bg-surface transition-colors disabled:opacity-50"
                  >
                    <RefreshCw className="h-4 w-4" />
                    Replace Video
                  </button>
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      setMenuOpen(false);
                      posterInputRef.current?.click();
                    }}
                    disabled={posterUploading}
                    className="w-full flex items-center gap-2 px-3 py-2.5 text-left hover:bg-surface transition-colors disabled:opacity-50"
                  >
                    <ImagePlus className="h-4 w-4" />
                    {customPoster ? "Change Poster" : "Upload Poster"}
                  </button>
                  {customPoster && (
                    <button
                      type="button"
                      role="menuitem"
                      onClick={() => {
                        setMenuOpen(false);
                        void removePoster();
                      }}
                      disabled={posterUploading}
                      className="w-full flex items-center gap-2 px-3 py-2.5 text-left hover:bg-surface transition-colors disabled:opacity-50"
                    >
                      <ImageOff className="h-4 w-4" />
                      Remove Poster
                    </button>
                  )}
                  <div className="h-px bg-border" />
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      setMenuOpen(false);
                      setConfirmDelete(true);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2.5 text-left text-red-600 hover:bg-red-500/10 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                    Delete Video
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Upload progress bar overlay (during replace) */}
          {uploading && (
            <div className="absolute top-0 inset-x-0 z-30 h-1 bg-white/10">
              <div
                className="h-full bg-[#e50914] transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          )}

          {(uploadError || posterError) && hovering && (
            <div className="absolute top-14 right-3 z-30 max-w-xs inline-flex items-start gap-2 px-3 py-2 rounded-md bg-red-600/95 text-white text-xs shadow">
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{uploadError ?? posterError}</span>
            </div>
          )}
        </>
      )}

      {/* Hidden inputs (admin only) */}
      {isAdmin && (
        <>
          <input ref={inputRef} type="file" accept={ACCEPT} className="hidden" onChange={onPick} />
          <input
            ref={posterInputRef}
            type="file"
            accept={POSTER_ACCEPT}
            className="hidden"
            onChange={onPickPoster}
          />
        </>
      )}

      {/* Delete confirmation */}
      {confirmDelete &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-[110] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
            onClick={() => !deleting && setConfirmDelete(false)}
          >
            <div
              className="w-full max-w-sm rounded-2xl bg-background border border-border p-6 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="font-heading text-lg font-semibold mb-2">Delete introduction video?</h3>
              <p className="text-sm text-muted-foreground mb-5">
                Are you sure you want to delete your introduction video? This can't be undone.
              </p>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  disabled={deleting}
                  className="px-4 py-2 rounded-full text-sm font-semibold border border-border hover:bg-surface transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={doDelete}
                  disabled={deleting}
                  className="px-4 py-2 rounded-full text-sm font-semibold bg-red-600 text-white hover:bg-red-700 transition-colors disabled:opacity-60 inline-flex items-center gap-2"
                >
                  {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                  Delete
                </button>
              </div>
            </div>
          </div>,
          document.body,
        )}
    </div>
  );
}
