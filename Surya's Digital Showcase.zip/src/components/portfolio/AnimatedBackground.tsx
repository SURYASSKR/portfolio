import { motion, useReducedMotion } from "framer-motion";

/**
 * Cinematic ambient layer: drifting blurred gradient blobs + animated grid.
 * Positioned absolutely; place inside a `relative overflow-hidden` parent.
 */
export function AnimatedBackground({
  variant = "light",
}: {
  variant?: "light" | "dark";
}) {
  const reduce = useReducedMotion();
  const blobs = [
    {
      className:
        "left-[-10%] top-[-10%] size-[55vw] bg-[radial-gradient(circle_at_30%_30%,var(--color-accent),transparent_60%)]",
      anim: { x: [0, 60, -30, 0], y: [0, 40, 20, 0], scale: [1, 1.15, 0.95, 1] },
      duration: 22,
    },
    {
      className:
        "right-[-15%] top-[10%] size-[50vw] bg-[radial-gradient(circle_at_70%_40%,var(--color-primary),transparent_65%)]",
      anim: { x: [0, -50, 30, 0], y: [0, 30, -20, 0], scale: [1, 1.1, 1.05, 1] },
      duration: 28,
    },
    {
      className:
        "left-[20%] bottom-[-20%] size-[60vw] bg-[radial-gradient(circle_at_50%_50%,var(--color-accent),transparent_55%)]",
      anim: { x: [0, 40, -40, 0], y: [0, -30, 20, 0], scale: [1, 1.2, 0.9, 1] },
      duration: 34,
    },
  ];

  return (
    <div aria-hidden className="absolute inset-0 pointer-events-none overflow-hidden">
      <div className={variant === "dark" ? "opacity-30" : "opacity-25"}>
        {blobs.map((b, i) => (
          <motion.div
            key={i}
            className={`absolute rounded-full blur-3xl ${b.className}`}
            animate={reduce ? undefined : b.anim}
            transition={{
              duration: b.duration,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      {/* animated grid pan */}
      <motion.div
        className="absolute inset-0 opacity-[0.05]"
        style={{
          backgroundImage:
            "linear-gradient(to right, currentColor 1px, transparent 1px), linear-gradient(to bottom, currentColor 1px, transparent 1px)",
          backgroundSize: "80px 80px",
        }}
        animate={reduce ? undefined : { backgroundPosition: ["0px 0px", "80px 80px"] }}
        transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
      />

      {/* drifting accent particles */}
      {!reduce &&
        Array.from({ length: 12 }).map((_, i) => (
          <motion.span
            key={i}
            className="absolute size-1 rounded-full bg-accent/60"
            style={{
              left: `${(i * 83) % 100}%`,
              top: `${(i * 47) % 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: 4 + (i % 5),
              repeat: Infinity,
              delay: i * 0.3,
              ease: "easeInOut",
            }}
          />
        ))}
    </div>
  );
}
