/**
 * Server-only helpers for resolving which portfolio a request belongs to.
 * Every content read is scoped to a portfolio slug; every write is scoped to
 * the portfolio owned by the authenticated caller.
 */

export type PortfolioRow = {
  id: string;
  user_id: string;
  slug: string;
  display_name: string;
  template_version: string;
  published: boolean;
};

export const DEFAULT_PORTFOLIO_SLUG = "surya-kiran";

export async function findPortfolioBySlug(slug: string): Promise<PortfolioRow | null> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await (supabaseAdmin as any)
    .from("portfolios")
    .select("id,user_id,slug,display_name,template_version,published")
    .eq("slug", slug)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as PortfolioRow) ?? null;
}

/** Resolve a public (published) portfolio, or null. */
export async function findPublicPortfolio(slug: string): Promise<PortfolioRow | null> {
  const row = await findPortfolioBySlug(slug);
  if (!row || !row.published) return null;
  return row;
}

export async function requirePublicPortfolio(slug: string): Promise<PortfolioRow> {
  const row = await findPublicPortfolio(slug);
  if (!row) throw new Error("Portfolio not found");
  return row;
}

export async function findPortfolioByUser(userId: string): Promise<PortfolioRow | null> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await (supabaseAdmin as any)
    .from("portfolios")
    .select("id,user_id,slug,display_name,template_version,published")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as PortfolioRow) ?? null;
}

/** The caller must own a portfolio to mutate anything. */
export async function requireOwnedPortfolio(userId: string): Promise<PortfolioRow> {
  const row = await findPortfolioByUser(userId);
  if (!row) throw new Error("You don't have a portfolio yet. Create one first.");
  return row;
}

/** Storage paths are namespaced per portfolio so users never collide. */
export function mediaPrefix(portfolioId: string) {
  return `${portfolioId}/`;
}
