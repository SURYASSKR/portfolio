import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const BUCKET = "resume";
const SIGNED_TTL = 300; // 5 minutes

function objectPath(portfolioId: string) {
  return `${portfolioId}/resume.pdf`;
}

/** Public: signed download URL for a published portfolio's resume. */
export const getResumeUrl = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => z.object({ portfolioSlug: z.string().max(60) }).parse(data))
  .handler(async ({ data }) => {
    const { findPublicPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await findPublicPortfolio(data.portfolioSlug);
    if (!portfolio) return { url: null as string | null };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: list } = await supabaseAdmin.storage
      .from(BUCKET)
      .list(portfolio.id, { limit: 100 });
    const exists = (list ?? []).some((o) => o.name === "resume.pdf");
    if (!exists) return { url: null as string | null };

    const { data: signed, error } = await supabaseAdmin.storage
      .from(BUCKET)
      .createSignedUrl(objectPath(portfolio.id), SIGNED_TTL, { download: "resume.pdf" });
    if (error) throw new Error(error.message);
    return { url: signed.signedUrl };
  });

const uploadSchema = z.object({
  base64: z.string().min(1),
  contentType: z.literal("application/pdf"),
});

export const uploadResume = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => uploadSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await requireOwnedPortfolio(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const buf = Buffer.from(data.base64, "base64");
    if (buf.length === 0) throw new Error("Empty file");
    if (buf.length > 10 * 1024 * 1024) throw new Error("File exceeds 10 MB");

    const { error } = await supabaseAdmin.storage
      .from(BUCKET)
      .upload(objectPath(portfolio.id), buf, {
        contentType: "application/pdf",
        upsert: true,
      });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteResume = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await requireOwnedPortfolio(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.storage
      .from(BUCKET)
      .remove([objectPath(portfolio.id)]);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
