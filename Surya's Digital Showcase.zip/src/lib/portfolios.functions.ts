import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type PublicPortfolio = {
  id: string;
  slug: string;
  display_name: string;
  template_version: string;
  published: boolean;
};

export const RESERVED_SLUGS = [
  "admin",
  "auth",
  "api",
  "p",
  "dashboard",
  "login",
  "logout",
  "signup",
  "register",
  "settings",
  "account",
  "static",
  "assets",
  "public",
  "new",
  "create",
  "pricing",
  "about",
];

export const slugSchema = z
  .string()
  .trim()
  .toLowerCase()
  .min(3)
  .max(50)
  .regex(/^[a-z0-9]([a-z0-9-]*[a-z0-9])$/, "Use lowercase letters, numbers and dashes")
  .refine((s) => !RESERVED_SLUGS.includes(s), "That address is reserved");

export function slugifyName(input: string): string {
  return (
    input
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s-]/g, "")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .slice(0, 40) || "portfolio"
  );
}

/** Public: resolve a published portfolio by its URL slug. */
export const getPublicPortfolio = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => z.object({ slug: z.string().max(60) }).parse(data))
  .handler(async ({ data }): Promise<PublicPortfolio | null> => {
    const { findPublicPortfolio } = await import("./portfolio-scope.server");
    const row = await findPublicPortfolio(data.slug);
    if (!row) return null;
    const { user_id: _u, ...pub } = row;
    return pub;
  });

/** The signed-in user's own portfolio (published or not). */
export const getMyPortfolio = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<PublicPortfolio | null> => {
    const { findPortfolioByUser } = await import("./portfolio-scope.server");
    const row = await findPortfolioByUser(context.userId);
    if (!row) return null;
    const { user_id: _u, ...pub } = row;
    return pub;
  });

export const checkSlugAvailable = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ slug: z.string().max(60) }).parse(data))
  .handler(async ({ data }) => {
    const parsed = slugSchema.safeParse(data.slug);
    if (!parsed.success) {
      return { available: false, reason: parsed.error.issues[0]?.message ?? "Invalid address" };
    }
    const { findPortfolioBySlug } = await import("./portfolio-scope.server");
    const existing = await findPortfolioBySlug(parsed.data);
    return existing
      ? { available: false, reason: "That address is already taken" }
      : { available: true, reason: "" };
  });

/**
 * Creates the caller's portfolio from the default template (v1.0) with their
 * own starter content. Never copies another user's data.
 */
export const createMyPortfolio = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        slug: slugSchema,
        display_name: z.string().trim().min(1).max(80),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { findPortfolioByUser, findPortfolioBySlug } = await import(
      "./portfolio-scope.server"
    );
    const existing = await findPortfolioByUser(context.userId);
    if (existing) throw new Error("You already have a portfolio");
    const taken = await findPortfolioBySlug(data.slug);
    if (taken) throw new Error("That address is already taken");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;

    const { data: portfolio, error } = await db
      .from("portfolios")
      .insert({
        user_id: context.userId,
        slug: data.slug,
        display_name: data.display_name,
        template_version: "1.0",
        published: true,
      })
      .select("id,slug,display_name,template_version,published")
      .single();
    if (error) throw new Error(error.message);

    const [firstName, ...rest] = data.display_name.split(" ");
    const { seedPortfolioContent } = await import("./portfolio-template.server");
    await seedPortfolioContent(portfolio.id, firstName, rest.join(" "));

    return portfolio as PublicPortfolio;
  });

export const updateMyPortfolio = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        slug: slugSchema.optional(),
        display_name: z.string().trim().min(1).max(80).optional(),
        published: z.boolean().optional(),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { requireOwnedPortfolio, findPortfolioBySlug } = await import(
      "./portfolio-scope.server"
    );
    const mine = await requireOwnedPortfolio(context.userId);
    if (data.slug && data.slug !== mine.slug) {
      const taken = await findPortfolioBySlug(data.slug);
      if (taken) throw new Error("That address is already taken");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any)
      .from("portfolios")
      .update(data)
      .eq("id", mine.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
