import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type Stat = {
  id: string;
  key: string;
  label: string;
  value: string;
  suffix: string;
  sort_order: number;
};

export const getStats = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => z.object({ portfolioSlug: z.string().max(60) }).parse(data))
  .handler(async ({ data }) => {
    const { findPublicPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await findPublicPortfolio(data.portfolioSlug);
    if (!portfolio) return [] as Stat[];
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await (supabaseAdmin as any)
      .from("stats")
      .select("id, key, label, value, suffix, sort_order")
      .eq("portfolio_id", portfolio.id)
      .order("sort_order", { ascending: true });
    if (error) throw new Error(error.message);
    return (rows ?? []) as Stat[];
  });

const updateSchema = z.object({
  id: z.string().uuid(),
  value: z.string().trim().min(1).max(20),
  suffix: z.string().trim().max(10).optional().default(""),
  label: z.string().trim().min(1).max(50).optional(),
});

export const updateStat = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => updateSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await requireOwnedPortfolio(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;

    const { data: row, error: rowErr } = await db
      .from("stats")
      .select("portfolio_id")
      .eq("id", data.id)
      .maybeSingle();
    if (rowErr) throw new Error(rowErr.message);
    if (!row || row.portfolio_id !== portfolio.id) throw new Error("Stat not found");

    const patch: { value: string; suffix: string; label?: string } = {
      value: data.value,
      suffix: data.suffix ?? "",
    };
    if (data.label) patch.label = data.label;

    const { error } = await db.from("stats").update(patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** True when the signed-in user owns the portfolio identified by slug. */
export const checkIsOwner = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ portfolioSlug: z.string().max(60) }).parse(data))
  .handler(async ({ data, context }) => {
    const { findPortfolioBySlug } = await import("./portfolio-scope.server");
    const portfolio = await findPortfolioBySlug(data.portfolioSlug);
    return { isOwner: Boolean(portfolio && portfolio.user_id === context.userId) };
  });

export const checkIsAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (error) throw new Error(error.message);
    return { isAdmin: Boolean(data) };
  });
