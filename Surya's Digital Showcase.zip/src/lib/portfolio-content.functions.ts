import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type SiteContent = {
  first_name: string;
  last_name: string;
  opportunity_text: string;
  hero_bio: string;
  contact_email: string;
};

export type ExperienceEntry = {
  id: string;
  period: string;
  role: string;
  organization: string;
  track: string;
  note: string;
  is_current: boolean;
  sort_order: number;
};

export type SkillGroup = {
  id: string;
  title: string;
  items: string[];
  sort_order: number;
};

export type ContactMessage = {
  id: string;
  name: string;
  email: string;
  message: string;
  read_at: string | null;
  created_at: string;
};

const siteSchema = z.object({
  first_name: z.string().trim().min(1).max(60),
  last_name: z.string().trim().min(1).max(60),
  opportunity_text: z.string().trim().min(1).max(180),
  hero_bio: z.string().trim().min(1).max(1500),
  contact_email: z.string().trim().email().max(254),
});

const experienceFields = z.object({
  period: z.string().trim().min(1).max(80),
  role: z.string().trim().min(1).max(120),
  organization: z.string().trim().max(120).default(""),
  track: z.string().trim().max(80).default(""),
  note: z.string().trim().max(1000).default(""),
  is_current: z.boolean().default(false),
  sort_order: z.number().int().min(0).max(9999).default(0),
});

const skillFields = z.object({
  title: z.string().trim().min(1).max(80),
  items: z.array(z.string().trim().min(1).max(80)).min(1).max(30),
  sort_order: z.number().int().min(0).max(9999).default(0),
});

const EMPTY_SITE: SiteContent = {
  first_name: "",
  last_name: "",
  opportunity_text: "",
  hero_bio: "",
  contact_email: "",
};

/** Public read of one portfolio's content. */
export const getPortfolioContent = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => z.object({ portfolioSlug: z.string().max(60) }).parse(data))
  .handler(async ({ data }) => {
    const { findPublicPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await findPublicPortfolio(data.portfolioSlug);
    if (!portfolio) {
      return { site: EMPTY_SITE, experience: [] as ExperienceEntry[], skills: [] as SkillGroup[] };
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const [siteResult, experienceResult, skillsResult] = await Promise.all([
      db
        .from("site_content")
        .select("first_name,last_name,opportunity_text,hero_bio,contact_email")
        .eq("portfolio_id", portfolio.id)
        .maybeSingle(),
      db
        .from("experience_entries")
        .select("id,period,role,organization,track,note,is_current,sort_order")
        .eq("portfolio_id", portfolio.id)
        .order("sort_order"),
      db
        .from("skill_groups")
        .select("id,title,items,sort_order")
        .eq("portfolio_id", portfolio.id)
        .order("sort_order"),
    ]);
    if (experienceResult.error) throw new Error(experienceResult.error.message);
    if (skillsResult.error) throw new Error(skillsResult.error.message);
    return {
      site: (siteResult.data as SiteContent) ?? EMPTY_SITE,
      experience: (experienceResult.data ?? []) as ExperienceEntry[],
      skills: (skillsResult.data ?? []) as SkillGroup[],
    };
  });

async function ownPortfolioId(userId: string) {
  const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
  return (await requireOwnedPortfolio(userId)).id;
}

async function assertOwnsRow(table: string, id: string, portfolioId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await (supabaseAdmin as any)
    .from(table)
    .select("portfolio_id")
    .eq("id", id)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data || data.portfolio_id !== portfolioId) throw new Error("Not found");
}

export const updateSiteContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => siteSchema.parse(data))
  .handler(async ({ data, context }) => {
    const portfolioId = await ownPortfolioId(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { data: existing } = await db
      .from("site_content")
      .select("id")
      .eq("portfolio_id", portfolioId)
      .maybeSingle();
    const { error } = existing
      ? await db.from("site_content").update(data).eq("portfolio_id", portfolioId)
      : await db.from("site_content").insert({ ...data, portfolio_id: portfolioId });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const saveExperience = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({ id: z.string().uuid().optional(), fields: experienceFields }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const portfolioId = await ownPortfolioId(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    if (data.id) await assertOwnsRow("experience_entries", data.id, portfolioId);
    const query = data.id
      ? db.from("experience_entries").update(data.fields).eq("id", data.id)
      : db.from("experience_entries").insert({ ...data.fields, portfolio_id: portfolioId });
    const { error } = await query;
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteExperience = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const portfolioId = await ownPortfolioId(context.userId);
    await assertOwnsRow("experience_entries", data.id, portfolioId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any)
      .from("experience_entries")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const saveSkillGroup = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({ id: z.string().uuid().optional(), fields: skillFields }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const portfolioId = await ownPortfolioId(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    if (data.id) await assertOwnsRow("skill_groups", data.id, portfolioId);
    const query = data.id
      ? db.from("skill_groups").update(data.fields).eq("id", data.id)
      : db.from("skill_groups").insert({ ...data.fields, portfolio_id: portfolioId });
    const { error } = await query;
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteSkillGroup = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const portfolioId = await ownPortfolioId(context.userId);
    await assertOwnsRow("skill_groups", data.id, portfolioId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any)
      .from("skill_groups")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const contactSchema = z.object({
  portfolioSlug: z.string().max(60),
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(254),
  message: z.string().trim().min(10).max(3000),
  website: z.string().max(0).optional().default(""),
});

export const submitContactMessage = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => contactSchema.parse(data))
  .handler(async ({ data }) => {
    const { findPublicPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await findPublicPortfolio(data.portfolioSlug);
    if (!portfolio) throw new Error("Unable to send your message right now");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { website: _website, portfolioSlug: _slug, ...message } = data;
    const { error } = await (supabaseAdmin as any)
      .from("contact_messages")
      .insert({ ...message, portfolio_id: portfolio.id });
    if (error) throw new Error("Unable to send your message right now");
    return { ok: true };
  });

export const listContactMessages = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const portfolioId = await ownPortfolioId(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await (supabaseAdmin as any)
      .from("contact_messages")
      .select("id,name,email,message,read_at,created_at")
      .eq("portfolio_id", portfolioId)
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return (data ?? []) as ContactMessage[];
  });

export const markContactMessageRead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({ id: z.string().uuid(), read: z.boolean() }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const portfolioId = await ownPortfolioId(context.userId);
    await assertOwnsRow("contact_messages", data.id, portfolioId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any)
      .from("contact_messages")
      .update({ read_at: data.read ? new Date().toISOString() : null })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteContactMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const portfolioId = await ownPortfolioId(context.userId);
    await assertOwnsRow("contact_messages", data.id, portfolioId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any)
      .from("contact_messages")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
