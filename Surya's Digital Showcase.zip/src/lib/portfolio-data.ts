// Single source of truth — edit any field here and it propagates across the site.
import portrait from "@/assets/portrait.jpg";
import videoThumb from "@/assets/video-thumb.jpg";

export const profile = {
  firstName: "Surya",
  lastName: "Kiran",
  greeting: "Hi, I'm",
  roles: [
    "AI-Powered Business Analyst",
    "AI Product Developer",
  ],
  tagline:
    "Bridging the gap between raw data and actionable strategy through rigorous process mapping and AI-driven automation.",
  portrait,
  email: "hello@suryakiran.me",
  links: {
    linkedin: "https://linkedin.com/in/suryakiran",
    github: "https://github.com/suryakiran",
    calendar: "https://cal.com/suryakiran",
    resume: "/resume.pdf",
  },
};

export const stats = [
  { label: "INTERNSHIP EXPERIENCE", value: "0.9", suffix: "months" },
  { label: "Projects", value: "4", suffix: "+" },
  { label: "Industries", value: "02", suffix: "" },
  { label: "Efficiency", value: "30", suffix: "%" },
];

export const video = {
  title: "Meet Surya Kiran",
  duration: "03:42",
  thumbnail: videoThumb,
  src: "", // drop your mp4 URL here
  summary:
    "A three-minute walkthrough of how I translate ambiguous stakeholder requests into shipped, measurable AI workflows.",
};

export const journey = [
  {
    period: "2022 — PRESENT",
    role: "Lead Business Analyst",
    org: "TechCorp",
    track: "Career",
    note: "Spearheaded AI implementation across 12 departments, saving 4,000+ manual hours annually.",
    current: true,
  },
  {
    period: "2023",
    role: "Generative AI Specialization",
    org: "DeepLearning.AI",
    track: "AI",
    note: "Production LLM pipelines, RAG architectures, and evaluation frameworks.",
  },
  {
    period: "2020 — 2022",
    role: "Systems Consultant",
    org: "NexaData",
    track: "Career",
    note: "Optimized database architecture for high-frequency trading platforms.",
  },
  {
    period: "2021",
    role: "CBAP Certification",
    org: "IIBA",
    track: "Business Analysis",
    note: "Certified Business Analysis Professional — top 5% global cohort.",
  },
  {
    period: "2019 — 2020",
    role: "Junior Analyst",
    org: "Northwind",
    track: "Career",
    note: "Owned requirement gathering for a 40-stakeholder ERP migration.",
  },
  {
    period: "2018",
    role: "B.Tech, Computer Science",
    org: "VIT University",
    track: "Learning",
    note: "Graduated with distinction; thesis on operations research.",
  },
];

// Projects are now stored in the database — see src/lib/projects.functions.ts

export const skills = [
  { group: "Discovery", items: ["Requirement Gathering", "User Stories", "Stakeholder Mgmt", "Process Mapping"] },
  { group: "Data", items: ["SQL", "Power BI", "Excel", "DAX"] },
  { group: "Delivery", items: ["Jira", "Confluence", "Agile", "Scrum"] },
  { group: "AI & Automation", items: ["LLM Tooling", "RAG", "n8n", "Zapier", "Python"] },
];

export const coreStack = [
  { label: "Business Analysis", level: 95 },
  { label: "SQL / Power BI", level: 88 },
  { label: "AI & Automation", level: 92 },
  { label: "Stakeholder Mgmt", level: 90 },
];

export const metrics = [
  { label: "Projects Completed", value: 42 },
  { label: "Documents Generated", value: 380 },
  { label: "Processes Analyzed", value: 120 },
  { label: "Stakeholders Managed", value: 240 },
  { label: "AI Solutions Built", value: 18 },
  { label: "Hours Saved (Automation)", value: 12000 },
];

export const testimonials = [
  {
    name: "Priya Menon",
    role: "VP Operations",
    company: "Northwind Retail",
    quote:
      "Surya took a tangled procurement process and made it boring — which, in operations, is the highest compliment.",
  },
  {
    name: "David Chen",
    role: "Engineering Director",
    company: "TechCorp",
    quote:
      "Best BRDs I've ever shipped from. Engineering loved the clarity; product loved the rigor.",
  },
  {
    name: "Aisha Rahman",
    role: "Head of Analytics",
    company: "Fintech Co.",
    quote:
      "He bridges business and AI without the usual translation tax. Rare and valuable.",
  },
];

export const certifications = [
  "CBAP — Certified Business Analysis Professional",
  "PSPO I — Professional Scrum Product Owner",
  "Microsoft Power BI Data Analyst (PL-300)",
  "DeepLearning.AI — Generative AI with LLMs",
];

export const achievements = [
  "Saved $1.4M/yr through ledger automation at TechCorp",
  "Speaker — BA Summit 2024, Bangalore",
  "Top 5% global cohort, CBAP 2021",
  "Mentor — Women in Analytics India",
];
