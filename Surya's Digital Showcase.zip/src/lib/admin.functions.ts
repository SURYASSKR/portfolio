import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * One-time bootstrap: grants the `admin` role to the signed-in user when they
 * supply the site owner password (SITE_PASSWORD secret).
 */
export const claimAdminRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({ password: z.string().min(1).max(200) }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const expected = process.env["SITE_PASSWORD"];
    if (!expected) throw new Error("Owner password is not configured");
    if (data.password !== expected) throw new Error("Incorrect owner password");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any)
      .from("user_roles")
      .upsert(
        { user_id: context.userId, role: "admin" },
        { onConflict: "user_id,role", ignoreDuplicates: true },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getAdminOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { data: isAdmin, error: roleErr } = await db.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleErr) throw new Error(roleErr.message);
    if (!isAdmin) throw new Error("Forbidden: admin role required");

    const [projects, featured, messages, unread, experience, skills] = await Promise.all([
      db.from("projects").select("id", { count: "exact", head: true }),
      db.from("projects").select("id", { count: "exact", head: true }).eq("featured", true),
      db.from("contact_messages").select("id", { count: "exact", head: true }),
      db
        .from("contact_messages")
        .select("id", { count: "exact", head: true })
        .is("read_at", null),
      db.from("experience_entries").select("id", { count: "exact", head: true }),
      db.from("skill_groups").select("id", { count: "exact", head: true }),
    ]);

    const [videoList, resumeList] = await Promise.all([
      supabaseAdmin.storage.from("introduction-videos").list("", { limit: 100 }),
      supabaseAdmin.storage.from("resume").list("", { limit: 100 }),
    ]);

    return {
      projects: projects.count ?? 0,
      featured: featured.count ?? 0,
      messages: messages.count ?? 0,
      unread: unread.count ?? 0,
      experience: experience.count ?? 0,
      skills: skills.count ?? 0,
      hasVideo: (videoList.data ?? []).some((o) => o.name && !o.name.endsWith("/")),
      hasResume: (resumeList.data ?? []).some((o) => o.name === "resume.pdf"),
    };
  });
