/**
 * DEFAULT PORTFOLIO TEMPLATE — v1.0
 *
 * Structure/starter copy only. It contains NO personal data from any existing
 * portfolio; new users get their own independent rows.
 */

export const TEMPLATE_VERSION = "1.0";

export const TEMPLATE_STATS = [
  { key: "experience", label: "Experience", value: "0", suffix: "yrs", sort_order: 0 },
  { key: "projects", label: "Projects", value: "0", suffix: "+", sort_order: 1 },
  { key: "industries", label: "Industries", value: "0", suffix: "", sort_order: 2 },
  { key: "impact", label: "Impact", value: "0", suffix: "%", sort_order: 3 },
];

export const TEMPLATE_SKILL_GROUPS = [
  { title: "Discovery", items: ["Requirement Gathering", "User Stories"], sort_order: 0 },
  { title: "Data", items: ["SQL", "Excel"], sort_order: 1 },
  { title: "Delivery", items: ["Agile", "Jira"], sort_order: 2 },
  { title: "AI & Automation", items: ["LLM Tooling", "Automation"], sort_order: 3 },
];

export async function seedPortfolioContent(
  portfolioId: string,
  firstName: string,
  lastName: string,
) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const db = supabaseAdmin as any;

  await db.from("site_content").insert({
    portfolio_id: portfolioId,
    first_name: firstName || "Your",
    last_name: lastName || "Name",
    opportunity_text: "Open to new opportunities",
    hero_bio:
      "Add a short introduction about who you are, what you do, and the kind of problems you love solving.",
    contact_email: "",
  });

  await db
    .from("stats")
    .insert(TEMPLATE_STATS.map((s) => ({ ...s, portfolio_id: portfolioId })));

  await db
    .from("skill_groups")
    .insert(TEMPLATE_SKILL_GROUPS.map((s) => ({ ...s, portfolio_id: portfolioId })));

  await db.from("experience_entries").insert({
    portfolio_id: portfolioId,
    period: "2024 — Present",
    role: "Your role",
    organization: "Your company",
    track: "Career",
    note: "Describe what you do and the impact you've made.",
    is_current: true,
    sort_order: 0,
  });
}
