/** Slug of the portfolio rendered at the site root. */
export const DEFAULT_PORTFOLIO_SLUG = "surya-kiran";
