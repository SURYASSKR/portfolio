import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const VIDEO_BUCKET = "introduction-videos";
const POSTER_BUCKET = "introduction-posters";
const VIDEO_TTL = 60 * 60; // 1 hour
const POSTER_TTL = 60 * 60 * 24 * 7; // 1 week

const slugInput = z.object({ portfolioSlug: z.string().max(60) });

async function newestVideo(portfolioId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: objects, error } = await supabaseAdmin.storage
    .from(VIDEO_BUCKET)
    .list(portfolioId, { limit: 100, sortBy: { column: "created_at", order: "desc" } });
  if (error) return null;
  const files = (objects ?? []).filter((o) => o.name && !o.name.endsWith("/"));
  return files[0]?.name ?? null;
}

export const getIntroVideo = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => slugInput.parse(data))
  .handler(async ({ data }): Promise<{ name: string; url: string } | null> => {
    const { findPublicPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await findPublicPortfolio(data.portfolioSlug);
    if (!portfolio) return null;
    const name = await newestVideo(portfolio.id);
    if (!name) return null;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: signed, error } = await supabaseAdmin.storage
      .from(VIDEO_BUCKET)
      .createSignedUrl(`${portfolio.id}/${name}`, VIDEO_TTL);
    if (error) return null;
    return { name, url: signed.signedUrl };
  });

export const getIntroPoster = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => slugInput.parse(data))
  .handler(async ({ data }): Promise<string | null> => {
    const { findPublicPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await findPublicPortfolio(data.portfolioSlug);
    if (!portfolio) return null;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: objects } = await supabaseAdmin.storage
      .from(POSTER_BUCKET)
      .list(portfolio.id, { limit: 100 });
    if (!(objects ?? []).some((o) => o.name === "poster.jpg")) return null;
    const { data: signed, error } = await supabaseAdmin.storage
      .from(POSTER_BUCKET)
      .createSignedUrl(`${portfolio.id}/poster.jpg`, POSTER_TTL);
    if (error) return null;
    return signed.signedUrl;
  });

/** Owner-only: signed upload URL so large MP4s stream straight to storage. */
export const createIntroVideoUploadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await requireOwnedPortfolio(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Only one intro video per portfolio — clear the previous ones first.
    const { data: objects } = await supabaseAdmin.storage
      .from(VIDEO_BUCKET)
      .list(portfolio.id, { limit: 100 });
    const stale = (objects ?? [])
      .filter((o) => o.name && !o.name.endsWith("/"))
      .map((o) => `${portfolio.id}/${o.name}`);
    if (stale.length) await supabaseAdmin.storage.from(VIDEO_BUCKET).remove(stale);

    const path = `${portfolio.id}/intro-${Date.now()}.mp4`;
    const { data, error } = await supabaseAdmin.storage
      .from(VIDEO_BUCKET)
      .createSignedUploadUrl(path);
    if (error) throw new Error(error.message);
    return { bucket: VIDEO_BUCKET, path, token: data.token };
  });

export const deleteIntroVideo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await requireOwnedPortfolio(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: objects } = await supabaseAdmin.storage
      .from(VIDEO_BUCKET)
      .list(portfolio.id, { limit: 100 });
    const paths = (objects ?? [])
      .filter((o) => o.name && !o.name.endsWith("/"))
      .map((o) => `${portfolio.id}/${o.name}`);
    if (paths.length) await supabaseAdmin.storage.from(VIDEO_BUCKET).remove(paths);
    return { ok: true };
  });

export const uploadIntroPoster = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        base64: z.string().min(1),
        contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await requireOwnedPortfolio(context.userId);
    const buf = Buffer.from(data.base64, "base64");
    if (buf.length === 0) throw new Error("Empty file");
    if (buf.length > 10 * 1024 * 1024) throw new Error("File exceeds 10 MB");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.storage
      .from(POSTER_BUCKET)
      .upload(`${portfolio.id}/poster.jpg`, buf, {
        contentType: data.contentType,
        upsert: true,
      });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteIntroPoster = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await requireOwnedPortfolio(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.storage
      .from(POSTER_BUCKET)
      .remove([`${portfolio.id}/poster.jpg`]);
    return { ok: true };
  });
