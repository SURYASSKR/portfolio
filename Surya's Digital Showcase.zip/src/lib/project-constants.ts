export const PROJECT_CATEGORIES = [
  "AI Application",
  "Business Analysis",
  "Data Analytics",
  "Automation",
  "Dashboard",
  "Web Application",
  "Mobile Application",
  "Other",
] as const;

export const PROJECT_STATUSES = [
  { value: "completed", label: "Completed" },
  { value: "in_progress", label: "In Progress" },
  { value: "planned", label: "Planned" },
] as const;

export const COMMON_TECHNOLOGIES = [
  "AI",
  "Python",
  "SQL",
  "Power BI",
  "Excel",
  "React",
  "Next.js",
  "OpenAI",
  "LangChain",
  "Firebase",
  "Supabase",
  "Node.js",
  "TypeScript",
  "Tableau",
  "Airflow",
  "Snowflake",
  "Zapier",
  "n8n",
] as const;
