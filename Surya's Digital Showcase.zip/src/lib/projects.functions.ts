import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const BUCKET = "project-covers";
const SIGNED_TTL = 60 * 60 * 24 * 7; // 7 days

export type ProjectStatus = "completed" | "in_progress" | "planned";

export type Project = {
  id: string;
  slug: string;
  title: string;
  tagline: string;
  category: string;
  problem: string;
  solution: string;
  impact: string;
  cover_path: string;
  cover_url: string | null;
  gallery_paths: string[];
  gallery_urls: string[];
  live_url: string;
  github_url: string;
  case_study_url: string;
  video_url: string;
  technologies: string[];
  metrics: string[];
  status: ProjectStatus;
  featured: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
};

async function signCoverUrl(cover_path: string): Promise<string | null> {
  if (!cover_path) return null;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.storage
    .from(BUCKET)
    .createSignedUrl(cover_path, SIGNED_TTL);
  if (error) return null;
  return data.signedUrl;
}

async function attachSignedUrls(rows: any[]): Promise<Project[]> {
  return Promise.all(
    rows.map(async (r) => ({
      ...r,
      gallery_paths: r.gallery_paths ?? [],
      cover_url: await signCoverUrl(r.cover_path),
      gallery_urls: (
        await Promise.all(((r.gallery_paths ?? []) as string[]).map(signCoverUrl))
      ).filter(Boolean) as string[],
    })),
  );
}

function slugify(input: string): string {
  return (
    input
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s-]/g, "")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .slice(0, 80) || `project-${Date.now()}`
  );
}

async function uniqueSlug(portfolioId: string, base: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  let slug = base;
  let n = 1;
  while (true) {
    const { data: existing } = await (supabaseAdmin as any)
      .from("projects")
      .select("id")
      .eq("portfolio_id", portfolioId)
      .eq("slug", slug)
      .maybeSingle();
    if (!existing) return slug;
    n += 1;
    slug = `${base}-${n}`;
  }
}

/** Verifies the row belongs to the caller's portfolio. */
async function requireOwnedProject(userId: string, projectId: string) {
  const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
  const portfolio = await requireOwnedPortfolio(userId);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: row, error } = await (supabaseAdmin as any)
    .from("projects")
    .select("*")
    .eq("id", projectId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!row || row.portfolio_id !== portfolio.id) throw new Error("Project not found");
  return { portfolio, row };
}

const slugInput = z.object({ portfolioSlug: z.string().max(60) });

export const listProjects = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => slugInput.parse(data))
  .handler(async ({ data }) => {
    const { findPublicPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await findPublicPortfolio(data.portfolioSlug);
    if (!portfolio) return [] as Project[];
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await (supabaseAdmin as any)
      .from("projects")
      .select("*")
      .eq("portfolio_id", portfolio.id)
      .order("featured", { ascending: false })
      .order("sort_order", { ascending: true })
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return await attachSignedUrls(rows ?? []);
  });

export const getProjectBySlug = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) =>
    z.object({ slug: z.string(), portfolioSlug: z.string().max(60) }).parse(data),
  )
  .handler(async ({ data }) => {
    const { findPublicPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await findPublicPortfolio(data.portfolioSlug);
    if (!portfolio) return null;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await (supabaseAdmin as any)
      .from("projects")
      .select("*")
      .eq("portfolio_id", portfolio.id)
      .eq("slug", data.slug)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) return null;
    const [withUrl] = await attachSignedUrls([row]);
    return withUrl;
  });

const projectFieldsSchema = z.object({
  title: z.string().trim().min(1).max(120),
  tagline: z.string().trim().max(200).default(""),
  category: z.string().trim().min(1).max(60),
  problem: z.string().trim().max(4000).default(""),
  solution: z.string().trim().max(4000).default(""),
  impact: z.string().trim().max(4000).default(""),
  cover_path: z.string().trim().min(1),
  gallery_paths: z.array(z.string().trim().min(1).max(300)).max(12).default([]),
  live_url: z.string().trim().max(500).default(""),
  github_url: z.string().trim().max(500).default(""),
  case_study_url: z.string().trim().max(500).default(""),
  video_url: z.string().trim().max(500).default(""),
  technologies: z.array(z.string().trim().min(1).max(40)).max(50).default([]),
  metrics: z.array(z.string().trim().min(1).max(80)).max(20).default([]),
  status: z.enum(["completed", "in_progress", "planned"]).default("completed"),
  featured: z.boolean().default(false),
  sort_order: z.number().int().min(0).max(9999).default(0),
});

export const createProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => projectFieldsSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await requireOwnedPortfolio(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const slug = await uniqueSlug(portfolio.id, slugify(data.title));
    const { data: row, error } = await (supabaseAdmin as any)
      .from("projects")
      .insert({ ...data, slug, portfolio_id: portfolio.id })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        patch: projectFieldsSchema.partial(),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    await requireOwnedProject(context.userId, data.id);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any)
      .from("projects")
      .update(data.patch)
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const { row } = await requireOwnedProject(context.userId, data.id);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const paths = [
      ...(row?.cover_path ? [row.cover_path] : []),
      ...((row?.gallery_paths ?? []) as string[]),
    ];
    if (paths.length) {
      await supabaseAdmin.storage.from(BUCKET).remove(paths);
    }
    const { error } = await (supabaseAdmin as any)
      .from("projects")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const duplicateProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const { portfolio, row } = await requireOwnedProject(context.userId, data.id);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { id, created_at, updated_at, slug, title, featured, ...rest } = row as any;
    const newSlug = await uniqueSlug(portfolio.id, slugify(`${title}-copy`));
    const { error: insErr } = await (supabaseAdmin as any)
      .from("projects")
      .insert({
        ...rest,
        portfolio_id: portfolio.id,
        title: `${title} (Copy)`,
        slug: newSlug,
        featured: false,
      });
    if (insErr) throw new Error(insErr.message);
    return { ok: true };
  });

export const uploadProjectCover = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        base64: z.string().min(1),
        contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
        ext: z.enum(["jpg", "jpeg", "png", "webp"]),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { requireOwnedPortfolio } = await import("./portfolio-scope.server");
    const portfolio = await requireOwnedPortfolio(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const buf = Buffer.from(data.base64, "base64");
    if (buf.length === 0) throw new Error("Empty file");
    if (buf.length > 8 * 1024 * 1024) throw new Error("File exceeds 8 MB");
    const path = `${portfolio.id}/${crypto.randomUUID()}.${data.ext}`;
    const { error } = await supabaseAdmin.storage
      .from(BUCKET)
      .upload(path, buf, { contentType: data.contentType, upsert: false });
    if (error) throw new Error(error.message);
    const { data: signed, error: signErr } = await supabaseAdmin.storage
      .from(BUCKET)
      .createSignedUrl(path, SIGNED_TTL);
    if (signErr) throw new Error(signErr.message);
    return { path, url: signed.signedUrl };
  });
