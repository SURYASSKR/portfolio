import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  LayoutDashboard,
  Film,
  FolderKanban,
  FileText,
  Settings,
  LogOut,
  Plus,
  Pencil,
  Trash2,
  Copy,
  Loader2,
  ExternalLink,
  ShieldCheck,
  Star,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { DEFAULT_PORTFOLIO_SLUG } from "@/lib/portfolio-constants";
import { VideoIntro } from "@/components/portfolio/VideoIntro";
import { ProjectFormDialog } from "@/components/portfolio/ProjectFormDialog";
import { checkIsAdmin, getStats, updateStat } from "@/lib/stats.functions";
import { claimAdminRole, getAdminOverview } from "@/lib/admin.functions";
import {
  listProjects,
  deleteProject,
  duplicateProject,
  type Project,
} from "@/lib/projects.functions";
import { getResumeUrl, uploadResume, deleteResume } from "@/lib/resume.functions";
import {
  getPortfolioContent,
  updateSiteContent,
  saveSkillGroup,
  deleteSkillGroup,
  type SkillGroup,
} from "@/lib/portfolio-content.functions";

export const Route = createFileRoute("/_authenticated/admin_/dashboard")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — Surya Kiran Portfolio" },
      {
        name: "description",
        content: "Manage portfolio projects, introduction video, resume and site settings.",
      },
      { property: "og:title", content: "Admin Dashboard — Surya Kiran Portfolio" },
      {
        property: "og:description",
        content: "Private dashboard for managing portfolio content.",
      },
      { property: "og:type", content: "website" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminDashboard,
});

type SectionId = "overview" | "video" | "projects" | "resume" | "settings";

const SECTIONS: { id: SectionId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "overview", label: "Portfolio Overview", icon: LayoutDashboard },
  { id: "video", label: "Introduction Video", icon: Film },
  { id: "projects", label: "Projects", icon: FolderKanban },
  { id: "resume", label: "Resume", icon: FileText },
  { id: "settings", label: "Portfolio Settings", icon: Settings },
];

function AdminDashboard() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [section, setSection] = useState<SectionId>("overview");
  const [adminName, setAdminName] = useState("");

  useEffect(() => {
    void supabase.auth.getUser().then(({ data }) => {
      const u = data.user;
      if (!u) return;
      const meta = (u.user_metadata ?? {}) as Record<string, unknown>;
      setAdminName(
        String(meta['display_name'] ?? meta['username'] ?? u.email?.split("@")[0] ?? "Admin"),
      );
    });
  }, []);

  const fetchIsAdmin = useServerFn(checkIsAdmin);
  const adminQ = useQuery({ queryKey: ["is-admin"], queryFn: () => fetchIsAdmin() });


  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  if (adminQ.isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!adminQ.data?.isAdmin) {
    return <ClaimAdmin onDone={() => qc.invalidateQueries({ queryKey: ["is-admin"] })} onSignOut={signOut} />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground font-display">
      <header className="border-b border-border bg-surface/70 backdrop-blur sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <ShieldCheck className="h-4 w-4 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold truncate">Admin Dashboard</p>
              <p className="text-xs text-muted-foreground truncate">
                Signed in as {adminName || "Admin"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="outline" size="sm">
              <Link to="/">
                <ExternalLink className="mr-2 h-4 w-4" /> View site
              </Link>
            </Button>
            <Button variant="ghost" size="sm" onClick={signOut}>
              <LogOut className="mr-2 h-4 w-4" /> Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 grid gap-8 lg:grid-cols-[240px_1fr]">
        <nav className="flex lg:flex-col gap-2 overflow-x-auto lg:overflow-visible">
          {SECTIONS.map((s) => {
            const Icon = s.icon;
            const active = section === s.id;
            return (
              <button
                key={s.id}
                onClick={() => setSection(s.id)}
                className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium whitespace-nowrap transition-colors ${
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <Icon className="h-4 w-4" />
                {s.label}
              </button>
            );
          })}
        </nav>

        <main className="min-w-0">
          {section === "overview" && <OverviewSection />}
          {section === "video" && <VideoSection />}
          {section === "projects" && <ProjectsSection />}
          {section === "resume" && <ResumeSection />}
          {section === "settings" && <SettingsSection />}
        </main>
      </div>
    </div>
  );
}

function ClaimAdmin({ onDone, onSignOut }: { onDone: () => void; onSignOut: () => void }) {
  const claim = useServerFn(claimAdminRole);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await claim({ data: { password } });
      toast.success("Admin access granted");
      onDone();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not grant admin access");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="min-h-screen bg-background text-foreground font-display flex items-center justify-center px-6">
      <div className="w-full max-w-md rounded-3xl border border-border bg-surface p-8 shadow-sm">
        <h1 className="text-xl font-semibold tracking-tight">Admin access required</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          This account has no admin role yet. Enter the site owner password to unlock the
          dashboard.
        </p>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="owner-password">Owner password</Label>
            <Input
              id="owner-password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <Button type="submit" className="w-full" disabled={busy}>
            {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Unlock dashboard
          </Button>
        </form>
        <button
          onClick={onSignOut}
          className="mt-6 w-full text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          Sign out
        </button>
      </div>
    </main>
  );
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-3xl border border-border bg-surface p-6 shadow-sm ${className}`}>
      {children}
    </div>
  );
}

function SectionHeader({ title, description }: { title: string; description: string }) {
  return (
    <div className="mb-6">
      <h2 className="text-2xl font-semibold tracking-tight">{title}</h2>
      <p className="mt-1 text-sm text-muted-foreground">{description}</p>
    </div>
  );
}

function OverviewSection() {
  const fetchOverview = useServerFn(getAdminOverview);
  const q = useQuery({ queryKey: ["admin-overview"], queryFn: () => fetchOverview() });
  const d = q.data;

  const cards = [
    { label: "Projects", value: d?.projects ?? 0 },
    { label: "Featured", value: d?.featured ?? 0 },
    { label: "Messages", value: d?.messages ?? 0 },
    { label: "Unread messages", value: d?.unread ?? 0 },
    { label: "Experience entries", value: d?.experience ?? 0 },
    { label: "Skill groups", value: d?.skills ?? 0 },
  ];

  return (
    <div>
      <SectionHeader
        title="Portfolio Overview"
        description="A quick snapshot of everything published on your portfolio."
      />
      {q.isLoading ? (
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {cards.map((c) => (
              <Card key={c.label}>
                <p className="text-sm text-muted-foreground">{c.label}</p>
                <p className="mt-2 text-3xl font-semibold tracking-tight">{c.value}</p>
              </Card>
            ))}
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Card>
              <p className="text-sm text-muted-foreground">Introduction video</p>
              <p className="mt-2 text-lg font-medium">
                {d?.hasVideo ? "Published" : "Not uploaded"}
              </p>
            </Card>
            <Card>
              <p className="text-sm text-muted-foreground">Resume</p>
              <p className="mt-2 text-lg font-medium">
                {d?.hasResume ? "Published" : "Not uploaded"}
              </p>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

function VideoSection() {
  return (
    <div>
      <SectionHeader
        title="Manage Introduction Video"
        description="Upload, replace, preview or delete the video shown in your hero section. The homepage always plays the latest upload."
      />
      <div className="max-w-2xl">
        <VideoIntro
          isAdmin
          portfolioSlug={DEFAULT_PORTFOLIO_SLUG}
          name="Surya Kiran"
          label="Watch My Introduction"
        />
      </div>
    </div>
  );
}

function ProjectsSection() {
  const qc = useQueryClient();
  const fetchProjects = useServerFn(listProjects);
  const doDelete = useServerFn(deleteProject);
  const doDuplicate = useServerFn(duplicateProject);
  const q = useQuery({ queryKey: ["projects"], queryFn: () => fetchProjects({ data: { portfolioSlug: DEFAULT_PORTFOLIO_SLUG } }) });

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Project | null>(null);

  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["projects"] });
    void qc.invalidateQueries({ queryKey: ["admin-overview"] });
  };

  const del = useMutation({
    mutationFn: (id: string) => doDelete({ data: { id } }),
    onSuccess: () => {
      toast.success("Project deleted");
      refresh();
    },
    onError: (e: unknown) =>
      toast.error(e instanceof Error ? e.message : "Delete failed"),
  });

  const dup = useMutation({
    mutationFn: (id: string) => doDuplicate({ data: { id } }),
    onSuccess: () => {
      toast.success("Project duplicated");
      refresh();
    },
    onError: (e: unknown) =>
      toast.error(e instanceof Error ? e.message : "Duplicate failed"),
  });

  const projects = q.data ?? [];

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight">Projects</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Create, edit and delete case studies. All data is stored in the database.
          </p>
        </div>
        <Button
          onClick={() => {
            setEditing(null);
            setDialogOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" /> Add project
        </Button>
      </div>

      {q.isLoading ? (
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      ) : projects.length === 0 ? (
        <Card>
          <p className="text-sm text-muted-foreground">
            No projects yet. Click “Add project” to publish your first case study.
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {projects.map((p) => (
            <Card key={p.id} className="flex flex-wrap items-center gap-4 !p-4">
              <div className="h-14 w-20 shrink-0 overflow-hidden rounded-xl bg-muted">
                {p.cover_url ? (
                  <img
                    src={p.cover_url}
                    alt={`${p.title} cover`}
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                ) : null}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="truncate font-medium">{p.title}</p>
                  {p.featured && <Star className="h-4 w-4 text-primary" aria-label="Featured" />}
                </div>
                <p className="truncate text-xs text-muted-foreground">
                  {p.category} · {p.status.replace("_", " ")}
                  {p.technologies.length ? ` · ${p.technologies.slice(0, 3).join(", ")}` : ""}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setEditing(p);
                    setDialogOpen(true);
                  }}
                >
                  <Pencil className="h-4 w-4" />
                  <span className="sr-only">Edit {p.title}</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => dup.mutate(p.id)}
                  disabled={dup.isPending}
                >
                  <Copy className="h-4 w-4" />
                  <span className="sr-only">Duplicate {p.title}</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (confirm(`Delete “${p.title}”? This cannot be undone.`)) del.mutate(p.id);
                  }}
                  disabled={del.isPending}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                  <span className="sr-only">Delete {p.title}</span>
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <ProjectFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        project={editing ?? undefined}
      />
    </div>
  );
}

function ResumeSection() {
  const qc = useQueryClient();
  const fetchResume = useServerFn(getResumeUrl);
  const doUpload = useServerFn(uploadResume);
  const doDelete = useServerFn(deleteResume);
  const q = useQuery({ queryKey: ["resume-url"], queryFn: () => fetchResume({ data: { portfolioSlug: DEFAULT_PORTFOLIO_SLUG } }) });
  const [busy, setBusy] = useState(false);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    if (file.type !== "application/pdf") {
      toast.error("Please choose a PDF file");
      return;
    }
    setBusy(true);
    try {
      const buf = await file.arrayBuffer();
      let binary = "";
      const bytes = new Uint8Array(buf);
      for (let i = 0; i < bytes.length; i += 0x8000) {
        binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
      }
      await doUpload({ data: { base64: btoa(binary), contentType: "application/pdf" } });
      toast.success("Resume uploaded");
      void qc.invalidateQueries({ queryKey: ["resume-url"] });
      void qc.invalidateQueries({ queryKey: ["admin-overview"] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <SectionHeader
        title="Manage Resume"
        description="Upload the PDF visitors can preview and download from your hero section."
      />
      <Card className="space-y-4">
        <p className="text-sm">
          Current resume:{" "}
          {q.data?.url ? (
            <a
              href={q.data.url}
              target="_blank"
              rel="noreferrer"
              className="text-primary underline underline-offset-4"
            >
              Preview / download
            </a>
          ) : (
            <span className="text-muted-foreground">not uploaded</span>
          )}
        </p>
        <div className="flex flex-wrap items-center gap-3">
          <label className="inline-flex">
            <input
              type="file"
              accept="application/pdf"
              className="hidden"
              onChange={(e) => void onFile(e.target.files?.[0])}
            />
            <span className="inline-flex cursor-pointer items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90">
              {busy ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <FileText className="mr-2 h-4 w-4" />
              )}
              {q.data?.url ? "Replace resume" : "Upload resume"}
            </span>
          </label>
          {q.data?.url && (
            <Button
              variant="outline"
              onClick={async () => {
                if (!confirm("Delete the current resume?")) return;
                try {
                  await doDelete({});
                  toast.success("Resume deleted");
                  void qc.invalidateQueries({ queryKey: ["resume-url"] });
                  void qc.invalidateQueries({ queryKey: ["admin-overview"] });
                } catch (err) {
                  toast.error(err instanceof Error ? err.message : "Delete failed");
                }
              }}
            >
              <Trash2 className="mr-2 h-4 w-4" /> Delete
            </Button>
          )}
        </div>
        <p className="text-xs text-muted-foreground">PDF only · up to 10 MB</p>
      </Card>
    </div>
  );
}

function SettingsSection() {
  const qc = useQueryClient();
  const fetchContent = useServerFn(getPortfolioContent);
  const saveSite = useServerFn(updateSiteContent);
  const fetchStats = useServerFn(getStats);
  const saveStat = useServerFn(updateStat);

  const contentQ = useQuery({
    queryKey: ["portfolio-content"],
    queryFn: () => fetchContent({ data: { portfolioSlug: DEFAULT_PORTFOLIO_SLUG } }),
  });
  const statsQ = useQuery({ queryKey: ["stats"], queryFn: () => fetchStats({ data: { portfolioSlug: DEFAULT_PORTFOLIO_SLUG } }) });

  const [form, setForm] = useState<Record<string, string> | null>(null);
  const site = form ?? (contentQ.data?.site as Record<string, string> | undefined);

  const set = (k: string, v: string) =>
    setForm({ ...(site ?? {}), [k]: v } as Record<string, string>);

  const onSaveSite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!site) return;
    try {
      await saveSite({
        data: {
          first_name: site.first_name,
          last_name: site.last_name,
          opportunity_text: site.opportunity_text,
          hero_bio: site.hero_bio,
          contact_email: site.contact_email,
        },
      });
      toast.success("Portfolio settings saved");
      void qc.invalidateQueries({ queryKey: ["portfolio-content"] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    }
  };

  return (
    <div>
      <SectionHeader
        title="Portfolio Settings"
        description="Update your hero content and headline statistics."
      />

      <Card>
        {contentQ.isLoading || !site ? (
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        ) : (
          <form onSubmit={onSaveSite} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="first_name">First name</Label>
                <Input
                  id="first_name"
                  value={site.first_name ?? ""}
                  onChange={(e) => set("first_name", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="last_name">Last name</Label>
                <Input
                  id="last_name"
                  value={site.last_name ?? ""}
                  onChange={(e) => set("last_name", e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="opportunity_text">Availability line</Label>
              <Input
                id="opportunity_text"
                value={site.opportunity_text ?? ""}
                onChange={(e) => set("opportunity_text", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hero_bio">Hero bio</Label>
              <Textarea
                id="hero_bio"
                rows={5}
                value={site.hero_bio ?? ""}
                onChange={(e) => set("hero_bio", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contact_email">Contact email</Label>
              <Input
                id="contact_email"
                type="email"
                value={site.contact_email ?? ""}
                onChange={(e) => set("contact_email", e.target.value)}
              />
            </div>
            <Button type="submit">Save settings</Button>
          </form>
        )}
      </Card>

      <h3 className="mt-8 mb-3 text-lg font-semibold tracking-tight">Headline stats</h3>
      <div className="grid gap-4 sm:grid-cols-2">
        {(statsQ.data ?? []).map((s) => (
          <Card key={s.id} className="!p-4">
            <p className="text-sm font-medium">{s.label}</p>
            <form
              className="mt-3 flex items-center gap-2"
              onSubmit={async (e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                try {
                  await saveStat({
                    data: {
                      id: s.id,
                      value: String(fd.get("value") ?? ""),
                      suffix: String(fd.get("suffix") ?? ""),
                    },
                  });
                  toast.success(`${s.label} updated`);
                  void qc.invalidateQueries({ queryKey: ["stats"] });
                } catch (err) {
                  toast.error(err instanceof Error ? err.message : "Update failed");
                }
              }}
            >
              <Input name="value" defaultValue={s.value} className="w-24" aria-label={`${s.label} value`} />
              <Input
                name="suffix"
                defaultValue={s.suffix}
                className="w-20"
                aria-label={`${s.label} suffix`}
              />
              <Button type="submit" variant="outline" size="sm">
                Save
              </Button>
            </form>
          </Card>
        ))}
      </div>

      <SkillsEditor groups={contentQ.data?.skills ?? []} />
    </div>
  );
}

function SkillsEditor({ groups }: { groups: SkillGroup[] }) {
  const qc = useQueryClient();
  const save = useServerFn(saveSkillGroup);
  const remove = useServerFn(deleteSkillGroup);
  const [busy, setBusy] = useState(false);

  const refresh = () => qc.invalidateQueries({ queryKey: ["portfolio-content"] });

  const onSave = async (
    e: React.FormEvent<HTMLFormElement>,
    id?: string,
    reset = false,
  ) => {
    e.preventDefault();
    const el = e.currentTarget;
    const fd = new FormData(el);
    const title = String(fd.get("title") ?? "").trim();
    const items = String(fd.get("items") ?? "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (!title || items.length === 0) {
      toast.error("Add a title and at least one skill");
      return;
    }
    setBusy(true);
    try {
      await save({
        data: {
          ...(id ? { id } : {}),
          fields: {
            title,
            items,
            sort_order: Number(fd.get("sort_order") ?? 0) || 0,
          },
        },
      });
      toast.success(id ? "Skill group updated" : "Skill group added");
      if (reset) el.reset();
      void refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  };

  const onDelete = async (id: string) => {
    setBusy(true);
    try {
      await remove({ data: { id } });
      toast.success("Skill group removed");
      void refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <h3 className="mt-8 mb-1 text-lg font-semibold tracking-tight">Skills</h3>
      <p className="mb-3 text-sm text-muted-foreground">
        Separate individual skills with commas.
      </p>
      <div className="grid gap-4">
        {groups.map((g) => (
          <Card key={g.id} className="!p-4">
            <form
              className="grid gap-3 sm:grid-cols-[1fr_2fr_auto]"
              onSubmit={(e) => onSave(e, g.id)}
            >
              <Input name="title" defaultValue={g.title} aria-label="Group title" />
              <Input
                name="items"
                defaultValue={g.items.join(", ")}
                aria-label="Skills"
              />
              <input type="hidden" name="sort_order" value={g.sort_order} />
              <div className="flex items-center gap-2">
                <Button type="submit" variant="outline" size="sm" disabled={busy}>
                  Save
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  disabled={busy}
                  onClick={() => onDelete(g.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </form>
          </Card>
        ))}

        <Card className="!p-4">
          <p className="mb-3 text-sm font-medium">Add a skill group</p>
          <form
            className="grid gap-3 sm:grid-cols-[1fr_2fr_auto]"
            onSubmit={(e) => onSave(e, undefined, true)}
          >
            <Input name="title" placeholder="e.g. Data" aria-label="New group title" />
            <Input
              name="items"
              placeholder="SQL, Power BI, Excel"
              aria-label="New group skills"
            />
            <input type="hidden" name="sort_order" value={groups.length} />
            <Button type="submit" size="sm" disabled={busy}>
              <Plus className="h-4 w-4 mr-1" />
              Add
            </Button>
          </form>
        </Card>
      </div>
    </>
  );
}

