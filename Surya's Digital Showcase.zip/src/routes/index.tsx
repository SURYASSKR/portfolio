import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowRight, Mail, Check, X, Eye, Download, Search } from "lucide-react";
import {
  profile,
  stats as fallbackStats,
} from "@/lib/portfolio-data";
import { Reveal, RevealGroup, RevealItem } from "@/components/portfolio/Reveal";
import { LinkedinIcon, GithubIcon, YoutubeIcon, XIcon } from "@/components/portfolio/SocialIcons";
import { DEFAULT_PORTFOLIO_SLUG } from "@/lib/portfolio-constants";
import { VideoIntro } from "@/components/portfolio/VideoIntro";
import { ProjectCard } from "@/components/portfolio/ProjectCard";
import { getStats, type Stat } from "@/lib/stats.functions";
import { getResumeUrl } from "@/lib/resume.functions";
import {
  getPortfolioContent,
  submitContactMessage,
  type ExperienceEntry,
  type SkillGroup,
} from "@/lib/portfolio-content.functions";
import {
  listProjects,
  type Project,
} from "@/lib/projects.functions";
import { PROJECT_CATEGORIES, PROJECT_STATUSES } from "@/lib/project-constants";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  codeSplitGroupings: [],
  head: () => ({
    meta: [
      { title: `${profile.firstName} ${profile.lastName} — Business Analyst & AI Problem Solver` },
      {
        name: "description",
        content:
          "Portfolio of Surya Kiran — Business Analyst building AI-powered automation, requirement engineering, and data products that ship.",
      },
      { property: "og:title", content: `${profile.firstName} ${profile.lastName} — Portfolio` },
      { property: "og:description", content: profile.tagline },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Index,
});

const G_COLORS = ["#4285F4", "#EA4335", "#FBBC04", "#34A853"] as const;

function Index() {
  // Stats
  const fetchStats = useServerFn(getStats);
  const statsQ = useQuery({ queryKey: ["stats"], queryFn: () => fetchStats({ data: { portfolioSlug: DEFAULT_PORTFOLIO_SLUG } }) });
  const dbStats: Stat[] =
    statsQ.data ??
    fallbackStats.map((s, i) => ({
      id: `fallback-${i}`,
      key: s.label.toLowerCase(),
      label: s.label,
      value: s.value,
      suffix: s.suffix,
      sort_order: i,
    }));

  const [resumePreviewUrl, setResumePreviewUrl] = useState<string | null>(null);
  const fetchPortfolioContent = useServerFn(getPortfolioContent);
  const contentQ = useQuery({ queryKey: ["portfolio-content"], queryFn: () => fetchPortfolioContent({ data: { portfolioSlug: DEFAULT_PORTFOLIO_SLUG } }) });
  const site = contentQ.data?.site;

  return (
    <div className="bg-background text-foreground font-display selection:bg-[#4285F4] selection:text-white">
      {/* Nav */}
      <nav className="fixed top-0 w-full z-50 px-6 md:px-12 py-5 flex items-center justify-between border-b border-border bg-background/85 backdrop-blur-xl">
        <div className="font-heading font-semibold text-2xl tracking-tight">
          <span style={{ color: G_COLORS[0] }}>P</span>
          <span style={{ color: G_COLORS[1] }}>o</span>
          <span style={{ color: G_COLORS[2] }}>r</span>
          <span style={{ color: G_COLORS[0] }}>t</span>
          <span style={{ color: G_COLORS[3] }}>f</span>
          <span style={{ color: G_COLORS[1] }}>o</span>
          <span style={{ color: G_COLORS[2] }}>l</span>
          <span style={{ color: G_COLORS[0] }}>i</span>
          <span style={{ color: G_COLORS[3] }}>o</span>
        </div>
        <div className="flex gap-6 md:gap-8 items-center">
          {[
            { href: "#about", label: "About" },
            { href: "#work", label: "Projects" },
            { href: "#experience", label: "Experience" },
            { href: "#skills", label: "Skills" },
            { href: "#contact", label: "Contact" },
          ].map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="hidden sm:inline relative text-sm font-medium text-foreground/80 hover:text-foreground transition-colors after:absolute after:left-0 after:-bottom-1 after:h-[2px] after:w-0 after:bg-[#4285F4] hover:after:w-full after:transition-all"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#contact"
            className="text-sm font-semibold px-5 py-2.5 rounded-full bg-foreground text-background hover:bg-[#4285F4] transition-colors"
          >
            Contact Me
          </a>
          <Link
            to="/auth"
            className="text-sm font-semibold px-5 py-2.5 rounded-full border border-border text-foreground/80 hover:text-foreground hover:border-foreground transition-colors"
          >
            Login
          </Link>
        </div>
      </nav>

      {/* HERO */}
      <section className="relative flex flex-col justify-center px-6 md:px-16 pt-28 md:pt-32 pb-16 md:pb-20 overflow-hidden min-h-[calc(100vh-4rem)]">
        {/* Playful background dots */}
        <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="hidden md:block absolute top-24 right-[10%] w-64 h-64 rounded-full opacity-20 blur-2xl animate-drift"
            style={{ background: G_COLORS[0] }}
          />
          <div
            className="hidden md:block absolute bottom-32 left-[5%] w-72 h-72 rounded-full opacity-20 blur-2xl animate-drift"
            style={{ background: G_COLORS[1], animationDelay: "-5s" }}
          />
          <div
            className="hidden md:block absolute top-1/2 left-1/3 w-56 h-56 rounded-full opacity-15 blur-2xl animate-drift"
            style={{ background: G_COLORS[2], animationDelay: "-9s" }}
          />
          <div
            className="hidden md:block absolute bottom-10 right-1/4 w-52 h-52 rounded-full opacity-20 blur-2xl animate-drift"
            style={{ background: G_COLORS[3], animationDelay: "-3s" }}
          />
        </div>

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-12 lg:gap-16 items-center w-full max-w-7xl mx-auto">
          <div className="order-1">
            <Reveal>
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-border bg-background/70 backdrop-blur text-[11px] md:text-xs font-medium mb-6 max-w-full">
                <span className="g-dot animate-pulse shrink-0" style={{ background: G_COLORS[3] }} />
                 <span className="truncate">{site?.opportunity_text ?? "Open to Business Analyst, Data Analyst, Product Analyst & AI Opportunities"}</span>
              </div>
            </Reveal>
            <h1 className="font-heading text-[clamp(2.5rem,7vw,6rem)] leading-[0.98] tracking-tight font-medium">
              <Reveal>
                <span style={{ color: G_COLORS[2] }}>Hi</span>
                <span style={{ color: G_COLORS[1] }}>,</span>{" "}
                <span style={{ color: G_COLORS[3] }}>I'm</span>
              </Reveal>
              <Reveal delay={0.1}>
              <span className="block font-semibold">
                 <span style={{ color: G_COLORS[0] }}>{site?.first_name ?? profile.firstName}</span>{" "}
                 <span style={{ color: G_COLORS[1] }}>{site?.last_name ?? profile.lastName}</span>
                <span style={{ color: G_COLORS[2] }}>.</span>
              </span>
              </Reveal>
            </h1>
            <Reveal delay={0.25}>
              <p className="mt-6 max-w-[600px] text-[17px] md:text-[20px] lg:text-[22px] text-foreground/75 leading-[1.55] font-light">
                {site?.hero_bio ?? "Business and AI-focused professional transforming complex problems into actionable insights, data-driven solutions, efficient processes, and AI-powered workflows. I combine business analysis, data analytics, product thinking, automation, and modern AI tools to design practical solutions, build intelligent applications, and help organizations make better decisions."}
              </p>
            </Reveal>
            <Reveal delay={0.35}>
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <a
                  href="#work"
                  className="px-7 py-3.5 rounded-full bg-foreground text-background font-semibold text-sm inline-flex items-center justify-center gap-2 hover:bg-[#4285F4] hover:-translate-y-0.5 transition-all shadow-md hover:shadow-lg group"
                >
                  View My Work
                  <ArrowRight className="size-4 group-hover:translate-x-1 transition-transform" />
                </a>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      const { url } = await getResumeUrl({ data: { portfolioSlug: DEFAULT_PORTFOLIO_SLUG } });
                      if (!url) {
                        toast.error("Resume not available yet.");
                        return;
                      }
                      setResumePreviewUrl(url);
                    } catch (e) {
                      toast.error(e instanceof Error ? e.message : "Failed to load resume");
                    }
                  }}
                  className="px-7 py-3.5 rounded-full bg-background text-foreground border border-border font-semibold text-sm inline-flex items-center justify-center gap-2 hover:border-foreground hover:-translate-y-0.5 transition-all"
                >
                  <Eye className="size-4" />
                  Preview Resume
                </button>
              </div>
            </Reveal>
          </div>

          <Reveal className="order-2" delay={0.3}>
            <div className="relative w-full max-w-[620px] mx-auto animate-float">
              {/* Playful color rings behind video */}
              <div
                className="absolute -top-6 -left-6 w-20 h-20 rounded-full opacity-90 -z-10"
                style={{ background: G_COLORS[2] }}
              />
              <div
                className="absolute -bottom-6 -right-6 w-28 h-28 rounded-full opacity-90 -z-10"
                style={{ background: G_COLORS[0] }}
              />
              <div
                className="hidden md:block absolute top-1/3 -right-10 w-14 h-14 rounded-full opacity-90 -z-10"
                style={{ background: G_COLORS[1] }}
              />
              <div className="relative rounded-[22px] overflow-hidden bg-surface border border-white/60 dark:border-white/10 shadow-[0_20px_50px_-15px_rgba(0,0,0,0.25)] aspect-video transition-transform duration-500 hover:scale-[1.015]">
                <VideoIntro
                  portfolioSlug={DEFAULT_PORTFOLIO_SLUG}
                  poster={profile.portrait}
                   name={`${site?.first_name ?? profile.firstName} ${site?.last_name ?? profile.lastName}`}
                  duration="1:30 min"
                  label="Watch My Introduction"
                  isAdmin={false}
                />
              </div>
              <a
                href="#about"
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById("about")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="mt-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground font-medium transition-colors mx-auto"
              >
                Prefer reading? View my profile ↓
              </a>
            </div>
          </Reveal>
        </div>
      </section>

      {/* STATS */}
      <section id="about" className="px-6 md:px-16 py-24 max-w-7xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {dbStats.map((s, idx) => {
            const color = G_COLORS[idx % 4];
            return (
              <motion.div
                key={s.id}
                className="stat-card relative group rounded-3xl p-8 bg-surface border border-border"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1], delay: idx * 0.08 }}
              >
                <div
                  className="g-dot mb-6"
                  style={{ background: color, width: "0.9rem", height: "0.9rem" }}
                />
                <div className="font-heading text-5xl md:text-6xl font-semibold leading-none">
                  {s.value}
                  <span className="text-2xl" style={{ color }}>
                    {s.suffix}
                  </span>
                </div>
                <div className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mt-4">
                  {s.label}
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* WORK */}
      <ProjectsSection />

      <ExperienceSection entries={contentQ.data?.experience ?? []} />
      <SkillsSection groups={contentQ.data?.skills ?? []} />
      {/* CONTACT */}
      <ContactSection email={site?.contact_email ?? profile.email} />

      {/* Footer */}
      <footer className="px-6 md:px-16 py-10 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
        <span>
          © {new Date().getFullYear()} {profile.firstName} {profile.lastName}
        </span>
        <div className="flex gap-2 items-center">
          {G_COLORS.map((c) => (
            <span key={c} className="g-dot" style={{ background: c, width: "0.5rem", height: "0.5rem" }} />
          ))}
          <span className="ml-2">Made with care</span>
          <Link
            to="/auth"
            className="ml-3 text-xs text-muted-foreground/40 hover:text-muted-foreground/80 transition-colors"
          >
            Admin
          </Link>
        </div>
      </footer>

      {resumePreviewUrl && (
        <div
          className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm flex flex-col p-4 md:p-8"
          onClick={() => setResumePreviewUrl(null)}
        >
          <div
            className="flex items-center justify-between mb-3 text-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="font-heading font-semibold text-lg">Resume Preview</div>
            <div className="flex items-center gap-2">
              <a
                href={resumePreviewUrl}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-full bg-white text-black text-sm font-semibold inline-flex items-center gap-2 hover:bg-white/90"
              >
                <Download className="size-4" />
                Download
              </a>
              <button
                type="button"
                onClick={() => setResumePreviewUrl(null)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white"
                aria-label="Close resume preview"
              >
                <X className="size-5" />
              </button>
            </div>
          </div>
          <div
            className="flex-1 rounded-xl overflow-hidden bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <iframe
              src={resumePreviewUrl}
              title="Resume preview"
              className="w-full h-full border-0"
            />
          </div>
        </div>
      )}
    </div>
  );
}

function ExperienceSection({ entries }: { entries: ExperienceEntry[] }) {
  if (entries.length === 0) return null;
  return (
    <section id="experience" className="px-6 md:px-16 py-24 max-w-7xl mx-auto">
      <Reveal>
        <div className="text-sm font-semibold uppercase tracking-widest mb-4" style={{ color: G_COLORS[3] }}>
          Experience
        </div>
        <h2 className="font-heading text-5xl md:text-7xl font-medium tracking-tight mb-12">
          How I got <span style={{ color: G_COLORS[1] }}>here.</span>
        </h2>
      </Reveal>
      <div className="border-t border-border">
        {entries.map((entry, index) => (
          <Reveal key={entry.id} delay={index * 0.05}>
            <article className="grid md:grid-cols-[180px_1fr] gap-4 md:gap-10 py-8 border-b border-border">
              <div className="text-sm font-semibold text-muted-foreground">{entry.period}</div>
              <div>
                <div className="flex flex-wrap items-center gap-3">
                  <h3 className="font-heading text-2xl font-semibold">{entry.role}</h3>
                  {entry.is_current && <span className="text-xs font-semibold text-primary">Current</span>}
                </div>
                {(entry.organization || entry.track) && (
                  <p className="mt-1 text-sm text-muted-foreground">
                    {[entry.organization, entry.track].filter(Boolean).join(" · ")}
                  </p>
                )}
                {entry.note && <p className="mt-4 max-w-3xl text-foreground/75 leading-relaxed">{entry.note}</p>}
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

const SOCIAL_LINKS = [
  { label: "LinkedIn", href: "https://www.linkedin.com/in/suryakiran03", Icon: LinkedinIcon, handle: "Connect professionally" },
  { label: "GitHub", href: "", Icon: GithubIcon, handle: "Code & experiments" },
  { label: "YouTube", href: "", Icon: YoutubeIcon, handle: "Walkthroughs & demos" },
  { label: "X", href: "", Icon: XIcon, handle: "Notes & updates" },
].filter((s) => s.href);


function SkillsSection({ groups }: { groups: SkillGroup[] }) {
  return (
    <section id="skills" className="px-6 md:px-16 py-24 max-w-7xl mx-auto">
      <Reveal>
        <div className="text-sm font-semibold uppercase tracking-widest mb-4" style={{ color: G_COLORS[2] }}>
          Skills
        </div>
        <h2 className="font-heading text-5xl md:text-7xl font-medium tracking-tight mb-12">
          What I bring to the <span style={{ color: G_COLORS[0] }}>table.</span>
        </h2>
      </Reveal>
      {groups.length > 0 && (
        <RevealGroup className="grid md:grid-cols-2 gap-6" stagger={0.08}>
          {groups.map((group, index) => (
            <RevealItem key={group.id} direction="up">
              <article className="h-full rounded-3xl border border-border bg-surface p-8">
                <div className="g-dot mb-6" style={{ background: G_COLORS[index % 4] }} />
                <h3 className="font-heading text-2xl font-semibold">{group.title}</h3>
                <div className="mt-5 flex flex-wrap gap-2">
                  {group.items.map((item) => (
                    <span key={item} className="rounded-full border border-border bg-background px-3 py-1.5 text-sm">
                      {item}
                    </span>
                  ))}
                </div>
              </article>
            </RevealItem>
          ))}
        </RevealGroup>
      )}

      <Reveal>
        <h3 className="font-heading text-2xl font-semibold mt-16 mb-6">Find me online</h3>
      </Reveal>
      <RevealGroup className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4" stagger={0.06}>
        {SOCIAL_LINKS.map(({ label, href, Icon, handle }, index) => (
          <RevealItem key={label} direction="up">
            <a
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex h-full items-center gap-4 rounded-3xl border border-border bg-surface p-6 transition-colors hover:bg-background"
            >
              <span
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-background"
                style={{ background: G_COLORS[index % 4] }}
              >
                <Icon size={20} />
              </span>
              <span className="min-w-0">
                <span className="block font-heading text-lg font-semibold">{label}</span>
                <span className="block truncate text-sm text-muted-foreground">{handle}</span>
              </span>
              <ArrowRight size={18} className="ml-auto shrink-0 opacity-0 transition-opacity group-hover:opacity-100" />
            </a>
          </RevealItem>
        ))}
      </RevealGroup>
    </section>
  );
}


function ContactSection({ email }: { email: string }) {
  const [sent, setSent] = useState(false);
  const submitMessage = useServerFn(submitContactMessage);
  const [sending, setSending] = useState(false);
  const [name, setName] = useState("");
  const [senderEmail, setSenderEmail] = useState("");
  const [message, setMessage] = useState("");
  const [website, setWebsite] = useState("");
  return (
    <section id="contact" className="px-6 md:px-16 py-24 max-w-7xl mx-auto">
      <div className="rounded-[2.5rem] bg-surface border border-border p-10 md:p-16 relative overflow-hidden">
        {/* Corner color dots */}
        <div className="absolute top-8 right-8 flex gap-2">
          {G_COLORS.map((c) => (
            <span key={c} className="g-dot" style={{ background: c, width: "0.75rem", height: "0.75rem" }} />
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-start relative">
          <Reveal>
            <div className="text-sm font-semibold uppercase tracking-widest mb-4" style={{ color: G_COLORS[3] }}>
              Let's talk
            </div>
            <h2 className="font-heading text-5xl md:text-7xl font-medium tracking-tight leading-[0.95]">
              Got an idea?{" "}
              <span style={{ color: G_COLORS[0] }}>Let's</span>{" "}
              <span style={{ color: G_COLORS[1] }}>build</span>{" "}
              <span style={{ color: G_COLORS[2] }}>it</span>
              <span style={{ color: G_COLORS[3] }}>.</span>
            </h2>
            <a
               href={`mailto:${email}`}
              className="mt-8 inline-flex items-center gap-3 text-lg font-medium hover:text-[#4285F4] transition-colors group"
            >
              <Mail className="size-5" />
               {email}
              <ArrowRight className="size-4 group-hover:translate-x-1 transition-transform" />
            </a>
          </Reveal>

          <Reveal delay={0.15}>
            {sent ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="rounded-2xl border-2 border-border p-10 text-center bg-background"
              >
                <div
                  className="size-16 mx-auto mb-6 rounded-full flex items-center justify-center"
                  style={{ background: G_COLORS[3] }}
                >
                  <Check className="size-8 text-white" />
                </div>
                <div className="text-2xl font-heading font-semibold">Message received</div>
                <p className="mt-3 text-muted-foreground">I'll reply within 24 hours.</p>
              </motion.div>
            ) : (
              <form
                 onSubmit={async (e) => {
                  e.preventDefault();
                   setSending(true);
                   try {
                     await submitMessage({ data: { portfolioSlug: DEFAULT_PORTFOLIO_SLUG, name, email: senderEmail, message, website } });
                     setSent(true);
                   } catch (error) {
                     toast.error(error instanceof Error ? error.message : "Unable to send message");
                   } finally {
                     setSending(false);
                   }
                }}
                className="space-y-3"
              >
                <input
                  required
                  placeholder="Your name"
                   value={name}
                   onChange={(e) => setName(e.target.value)}
                  className="w-full bg-background border border-border rounded-full px-6 py-4 text-sm focus:outline-none focus:border-[#4285F4] transition-colors"
                />
                <input
                  required
                  type="email"
                  placeholder="Your email"
                   value={senderEmail}
                   onChange={(e) => setSenderEmail(e.target.value)}
                  className="w-full bg-background border border-border rounded-full px-6 py-4 text-sm focus:outline-none focus:border-[#4285F4] transition-colors"
                />
                <textarea
                  required
                  rows={5}
                  placeholder="What are we building?"
                   value={message}
                   minLength={10}
                   onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-background border border-border rounded-3xl px-6 py-4 text-sm focus:outline-none focus:border-[#4285F4] transition-colors resize-none"
                />
                 <input
                   tabIndex={-1}
                   autoComplete="off"
                   aria-hidden="true"
                   value={website}
                   onChange={(e) => setWebsite(e.target.value)}
                   className="hidden"
                 />
                <button
                  type="submit"
                   disabled={sending}
                  className="w-full bg-foreground text-background rounded-full py-4 px-8 font-semibold text-sm hover:bg-[#4285F4] transition-all flex items-center justify-center gap-2 group"
                >
                   {sending ? "Sending…" : "Send message"}
                  <ArrowRight className="size-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </form>
            )}
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function ProjectsSection() {
  const fetchProjects = useServerFn(listProjects);
  const projectsQ = useQuery({ queryKey: ["projects"], queryFn: () => fetchProjects({ data: { portfolioSlug: DEFAULT_PORTFOLIO_SLUG } }) });

  const [q, setQ] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [tech, setTech] = useState<string>("all");
  const [status, setStatus] = useState<string>("all");
  const [sort, setSort] = useState<string>("featured");

  const all = projectsQ.data ?? [];

  const allTechs = useMemo(() => {
    const set = new Set<string>();
    all.forEach((p) => p.technologies.forEach((t) => set.add(t)));
    return Array.from(set).sort();
  }, [all]);

  const filtered = useMemo(() => {
    let arr = [...all];
    if (q.trim()) {
      const s = q.toLowerCase();
      arr = arr.filter(
        (p: Project) =>
          p.title.toLowerCase().includes(s) ||
          p.tagline.toLowerCase().includes(s) ||
          p.problem.toLowerCase().includes(s) ||
          p.technologies.some((t) => t.toLowerCase().includes(s)),
      );
    }
    if (category !== "all") arr = arr.filter((p) => p.category === category);
    if (tech !== "all") arr = arr.filter((p) => p.technologies.includes(tech));
    if (status !== "all") arr = arr.filter((p) => p.status === status);

    switch (sort) {
      case "newest":
        arr.sort((a, b) => b.created_at.localeCompare(a.created_at));
        break;
      case "oldest":
        arr.sort((a, b) => a.created_at.localeCompare(b.created_at));
        break;
      case "alpha":
        arr.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "featured":
      default:
        arr.sort((a, b) => {
          if (a.featured !== b.featured) return a.featured ? -1 : 1;
          if (a.sort_order !== b.sort_order) return a.sort_order - b.sort_order;
          return b.created_at.localeCompare(a.created_at);
        });
    }
    return arr;
  }, [all, q, category, tech, status, sort]);

  return (
    <section id="work" className="px-6 md:px-16 py-24 max-w-7xl mx-auto">
      <Reveal>
        <div className="text-sm font-semibold uppercase tracking-widest mb-4" style={{ color: G_COLORS[1] }}>
          Selected work
        </div>
      </Reveal>
      <div className="flex flex-wrap items-end justify-between gap-6 mb-10">
        <Reveal delay={0.05}>
          <h2 className="font-heading text-5xl md:text-7xl font-medium tracking-tight max-w-3xl">
            Projects I'm <span style={{ color: G_COLORS[0] }}>proud</span> of.
          </h2>
        </Reveal>
      </div>

      {all.length > 0 && (
        <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_repeat(4,minmax(0,auto))] mb-10">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search projects…"
              className="pl-9 rounded-full"
            />
          </div>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="rounded-full min-w-[150px]"><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {PROJECT_CATEGORIES.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={tech} onValueChange={setTech}>
            <SelectTrigger className="rounded-full min-w-[140px]"><SelectValue placeholder="Tech" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All tech</SelectItem>
              {allTechs.map((t) => (
                <SelectItem key={t} value={t}>{t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="rounded-full min-w-[140px]"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {PROJECT_STATUSES.map((s) => (
                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="rounded-full min-w-[140px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="oldest">Oldest</SelectItem>
              <SelectItem value="alpha">Alphabetical</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      {projectsQ.isLoading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-96 rounded-3xl bg-muted/50 animate-pulse" />
          ))}
        </div>
      ) : all.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-border p-16 text-center">
          <p className="text-lg text-muted-foreground">No projects added yet.</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-border p-12 text-center text-muted-foreground">
          No projects match your filters.
        </div>
      ) : (
        <RevealGroup className="grid md:grid-cols-2 lg:grid-cols-3 gap-6" stagger={0.08}>
          {filtered.map((p, idx) => (
            <RevealItem key={p.id} direction="up">
              <ProjectCard
                project={p}
                color={G_COLORS[idx % 4]}
                isAdmin={false}
                onEdit={() => {}}
                onDuplicate={() => {}}
                onDelete={() => {}}
              />
            </RevealItem>
          ))}
        </RevealGroup>
      )}
    </section>
  );
}

