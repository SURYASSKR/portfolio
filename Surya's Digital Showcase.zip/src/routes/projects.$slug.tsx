import { useState } from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ExternalLink, Play, Code2, ChevronLeft, ChevronRight } from "lucide-react";
import { getProjectBySlug } from "@/lib/projects.functions";
import { DEFAULT_PORTFOLIO_SLUG } from "@/lib/portfolio-constants";
import { Reveal } from "@/components/portfolio/Reveal";

function ImageCarousel({ images, title }: { images: string[]; title: string }) {
  const [i, setI] = useState(0);
  if (images.length === 0) return null;
  const go = (d: number) => setI((v) => (v + d + images.length) % images.length);

  return (
    <section className="px-6 pb-8 max-w-6xl mx-auto">
      <div className="relative group w-full rounded-2xl bg-muted/50 shadow-lg overflow-hidden flex items-center justify-center">
        <img
          src={images[i]}
          alt={i === 0 ? title : `${title} screenshot ${i + 1}`}
          className="w-full h-auto max-h-[65vh] object-contain"
        />
        {images.length > 1 && (
          <>
            <button
              type="button"
              aria-label="Previous image"
              onClick={() => go(-1)}
              className="absolute left-3 top-1/2 -translate-y-1/2 grid place-items-center size-10 rounded-full bg-background/80 backdrop-blur border border-border shadow hover:bg-background transition"
            >
              <ChevronLeft className="size-5" />
            </button>
            <button
              type="button"
              aria-label="Next image"
              onClick={() => go(1)}
              className="absolute right-3 top-1/2 -translate-y-1/2 grid place-items-center size-10 rounded-full bg-background/80 backdrop-blur border border-border shadow hover:bg-background transition"
            >
              <ChevronRight className="size-5" />
            </button>
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
              {images.map((src, idx) => (
                <button
                  key={src}
                  type="button"
                  aria-label={`Go to image ${idx + 1}`}
                  onClick={() => setI(idx)}
                  className={`h-1.5 rounded-full transition-all ${idx === i ? "w-5 bg-foreground" : "w-1.5 bg-foreground/40"}`}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
}

export const Route = createFileRoute("/projects/$slug")({
  loader: async ({ params }) => {
    const project = await getProjectBySlug({ data: { slug: params.slug, portfolioSlug: DEFAULT_PORTFOLIO_SLUG } });
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.project.title} — Portfolio` },
          {
            name: "description",
            content:
              loaderData.project.tagline ||
              loaderData.project.problem ||
              loaderData.project.title,
          },
          { property: "og:title", content: loaderData.project.title },
          {
            property: "og:description",
            content: loaderData.project.tagline || loaderData.project.problem,
          },
          ...(loaderData.project.cover_url
            ? [{ property: "og:image", content: loaderData.project.cover_url }]
            : []),
        ]
      : [{ title: "Project not found" }, { name: "robots", content: "noindex" }],
  }),
  component: ProjectPage,
  notFoundComponent: () => (
    <div className="min-h-screen grid place-items-center">
      <Link to="/" className="font-mono text-xs uppercase">
        ← Project not found — back home
      </Link>
    </div>
  ),
  errorComponent: () => (
    <div className="min-h-screen grid place-items-center">
      <Link to="/" className="font-mono text-xs uppercase">
        ← Something went wrong — back home
      </Link>
    </div>
  ),
});

function ProjectPage() {
  const { project: p } = Route.useLoaderData() as { project: import("@/lib/projects.functions").Project };

  return (
    <div className="bg-background text-foreground font-display min-h-screen">
      <nav className="fixed top-0 w-full z-50 px-6 py-3 flex justify-between items-center border-b border-border bg-background/80 backdrop-blur-md">
        <Link
          to="/"
          className="font-mono text-[10px] uppercase tracking-widest flex items-center gap-2 hover:text-accent transition-colors"
        >
          <ArrowLeft className="size-3" /> Back to portfolio
        </Link>
        <div className="font-mono text-[10px] uppercase tracking-widest opacity-60">
          {p.category}
        </div>
      </nav>

      <header className="px-6 pt-20 pb-4 max-w-6xl mx-auto">
        <Reveal className="font-mono text-[10px] tracking-widest text-accent mb-2 uppercase">
          Case Study
        </Reveal>
        <Reveal delay={0.05}>
          <h1
            title={p.title}
            className="font-black tracking-tight leading-tight truncate text-[clamp(1.75rem,4vw,3rem)]"
          >
            {p.title}
          </h1>
        </Reveal>
        {p.tagline && (
          <Reveal delay={0.08}>
            <p className="mt-2 text-sm md:text-base text-muted-foreground max-w-2xl line-clamp-2">
              {p.tagline}
            </p>
          </Reveal>
        )}
        {p.technologies.length > 0 && (
          <Reveal delay={0.1}>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {p.technologies.slice(0, 8).map((t) => (
                <span
                  key={t}
                  className="border border-border px-2 py-0.5 font-mono text-[10px] uppercase rounded-full"
                >
                  {t}
                </span>
              ))}
            </div>
          </Reveal>
        )}
      </header>

      <ImageCarousel
        images={[...(p.cover_url ? [p.cover_url] : []), ...(p.gallery_urls ?? [])]}
        title={p.title}
      />

      {p.metrics.length > 0 && (
        <section className="px-6 py-10 border-t border-border max-w-6xl mx-auto">
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
            {p.metrics.map((m) => (
              <div key={m} className="border-t border-foreground pt-4">
                <div className="font-mono text-[10px] uppercase text-accent">Metric</div>
                <div className="text-2xl font-black mt-2 tracking-tighter">{m}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="px-6 py-16 grid lg:grid-cols-12 gap-12 border-t border-border max-w-6xl mx-auto">

        <div className="lg:col-span-4 space-y-8 lg:sticky lg:top-24 self-start">
          {p.technologies.length > 0 && (
            <div>
              <div className="font-mono text-[10px] uppercase text-accent mb-2">
                Technologies
              </div>
              <div className="flex flex-wrap gap-2">
                {p.technologies.map((t) => (
                  <span
                    key={t}
                    className="border border-border px-2 py-1 font-mono text-[10px] uppercase"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            {p.live_url && (
              <a
                href={p.live_url}
                target="_blank"
                rel="noreferrer"
                className="border border-border px-3 py-2 font-mono text-[10px] uppercase flex items-center gap-2 hover:bg-foreground hover:text-background"
              >
                <ExternalLink className="size-3" /> Live
              </a>
            )}
            {p.github_url && (
              <a
                href={p.github_url}
                target="_blank"
                rel="noreferrer"
                className="border border-border px-3 py-2 font-mono text-[10px] uppercase flex items-center gap-2 hover:bg-foreground hover:text-background"
              >
                <Code2 className="size-3" /> Code
              </a>
            )}
            {p.video_url && (
              <a
                href={p.video_url}
                target="_blank"
                rel="noreferrer"
                className="border border-border px-3 py-2 font-mono text-[10px] uppercase flex items-center gap-2 hover:bg-foreground hover:text-background"
              >
                <Play className="size-3" /> Video
              </a>
            )}
            {p.case_study_url && (
              <a
                href={p.case_study_url}
                target="_blank"
                rel="noreferrer"
                className="border border-border px-3 py-2 font-mono text-[10px] uppercase flex items-center gap-2 hover:bg-foreground hover:text-background"
              >
                Case study
              </a>
            )}
          </div>
        </div>

        <div className="lg:col-span-8 space-y-12">
          {p.problem && <Block num="01" title="Problem">{p.problem}</Block>}
          {p.solution && <Block num="02" title="Solution">{p.solution}</Block>}
          {p.impact && <Block num="03" title="Business impact">{p.impact}</Block>}
        </div>
      </section>

      <section className="px-6 py-16 border-b border-border bg-foreground text-background">
        <div className="font-mono text-xs text-accent mb-4">NEXT</div>
        <Link
          to="/"
          className="text-5xl md:text-6xl font-black tracking-tighter uppercase hover:text-accent transition-colors"
        >
          Back to all work →
        </Link>
      </section>
    </div>
  );
}

function Block({
  num,
  title,
  children,
}: {
  num: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <Reveal>
      <div className="grid grid-cols-12 gap-4 border-t border-border pt-6">
        <div className="col-span-2 font-mono text-[10px] uppercase opacity-60">
          ({num})
        </div>
        <div className="col-span-10">
          <h3 className="font-mono text-[10px] uppercase tracking-widest text-accent mb-3">
            {title}
          </h3>
          <p className="text-xl md:text-2xl leading-snug tracking-tight whitespace-pre-line">
            {children}
          </p>
        </div>
      </div>
    </Reveal>
  );
}
