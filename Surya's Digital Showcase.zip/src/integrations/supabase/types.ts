export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      contact_messages: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string
          name: string
          portfolio_id: string | null
          read_at: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          portfolio_id?: string | null
          read_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          portfolio_id?: string | null
          read_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "contact_messages_portfolio_id_fkey"
            columns: ["portfolio_id"]
            isOneToOne: false
            referencedRelation: "portfolios"
            referencedColumns: ["id"]
          },
        ]
      }
      experience_entries: {
        Row: {
          created_at: string
          id: string
          is_current: boolean
          note: string
          organization: string
          period: string
          portfolio_id: string
          role: string
          sort_order: number
          track: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_current?: boolean
          note?: string
          organization?: string
          period: string
          portfolio_id: string
          role: string
          sort_order?: number
          track?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_current?: boolean
          note?: string
          organization?: string
          period?: string
          portfolio_id?: string
          role?: string
          sort_order?: number
          track?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "experience_entries_portfolio_id_fkey"
            columns: ["portfolio_id"]
            isOneToOne: false
            referencedRelation: "portfolios"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_submissions: {
        Row: {
          amount_inr: number
          created_at: string
          id: string
          payer_name: string
          review_note: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
          upi_reference: string
          user_id: string
        }
        Insert: {
          amount_inr?: number
          created_at?: string
          id?: string
          payer_name?: string
          review_note?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          upi_reference: string
          user_id: string
        }
        Update: {
          amount_inr?: number
          created_at?: string
          id?: string
          payer_name?: string
          review_note?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          upi_reference?: string
          user_id?: string
        }
        Relationships: []
      }
      portfolios: {
        Row: {
          created_at: string
          display_name: string
          id: string
          published: boolean
          slug: string
          template_version: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name?: string
          id?: string
          published?: boolean
          slug: string
          template_version?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string
          id?: string
          published?: boolean
          slug?: string
          template_version?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          bio: string
          created_at: string
          display_name: string
          email: string | null
          role_title: string
          tagline: string
          updated_at: string
          user_id: string
          username: string | null
        }
        Insert: {
          bio?: string
          created_at?: string
          display_name?: string
          email?: string | null
          role_title?: string
          tagline?: string
          updated_at?: string
          user_id: string
          username?: string | null
        }
        Update: {
          bio?: string
          created_at?: string
          display_name?: string
          email?: string | null
          role_title?: string
          tagline?: string
          updated_at?: string
          user_id?: string
          username?: string | null
        }
        Relationships: []
      }
      projects: {
        Row: {
          case_study_url: string
          category: string
          cover_path: string
          created_at: string
          featured: boolean
          gallery_paths: string[]
          github_url: string
          id: string
          impact: string
          live_url: string
          metrics: string[]
          portfolio_id: string
          problem: string
          slug: string
          solution: string
          sort_order: number
          status: string
          tagline: string
          technologies: string[]
          title: string
          updated_at: string
          video_url: string
        }
        Insert: {
          case_study_url?: string
          category: string
          cover_path: string
          created_at?: string
          featured?: boolean
          gallery_paths?: string[]
          github_url?: string
          id?: string
          impact?: string
          live_url?: string
          metrics?: string[]
          portfolio_id: string
          problem?: string
          slug: string
          solution?: string
          sort_order?: number
          status?: string
          tagline?: string
          technologies?: string[]
          title: string
          updated_at?: string
          video_url?: string
        }
        Update: {
          case_study_url?: string
          category?: string
          cover_path?: string
          created_at?: string
          featured?: boolean
          gallery_paths?: string[]
          github_url?: string
          id?: string
          impact?: string
          live_url?: string
          metrics?: string[]
          portfolio_id?: string
          problem?: string
          slug?: string
          solution?: string
          sort_order?: number
          status?: string
          tagline?: string
          technologies?: string[]
          title?: string
          updated_at?: string
          video_url?: string
        }
        Relationships: [
          {
            foreignKeyName: "projects_portfolio_id_fkey"
            columns: ["portfolio_id"]
            isOneToOne: false
            referencedRelation: "portfolios"
            referencedColumns: ["id"]
          },
        ]
      }
      site_content: {
        Row: {
          contact_email: string
          first_name: string
          hero_bio: string
          id: string
          last_name: string
          opportunity_text: string
          portfolio_id: string
          updated_at: string
        }
        Insert: {
          contact_email?: string
          first_name?: string
          hero_bio?: string
          id?: string
          last_name?: string
          opportunity_text?: string
          portfolio_id: string
          updated_at?: string
        }
        Update: {
          contact_email?: string
          first_name?: string
          hero_bio?: string
          id?: string
          last_name?: string
          opportunity_text?: string
          portfolio_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "site_content_portfolio_id_fkey"
            columns: ["portfolio_id"]
            isOneToOne: false
            referencedRelation: "portfolios"
            referencedColumns: ["id"]
          },
        ]
      }
      skill_groups: {
        Row: {
          created_at: string
          id: string
          items: string[]
          portfolio_id: string
          sort_order: number
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          items?: string[]
          portfolio_id: string
          sort_order?: number
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          items?: string[]
          portfolio_id?: string
          sort_order?: number
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "skill_groups_portfolio_id_fkey"
            columns: ["portfolio_id"]
            isOneToOne: false
            referencedRelation: "portfolios"
            referencedColumns: ["id"]
          },
        ]
      }
      stats: {
        Row: {
          id: string
          key: string
          label: string
          portfolio_id: string
          sort_order: number
          suffix: string
          updated_at: string
          value: string
        }
        Insert: {
          id?: string
          key: string
          label: string
          portfolio_id: string
          sort_order?: number
          suffix?: string
          updated_at?: string
          value: string
        }
        Update: {
          id?: string
          key?: string
          label?: string
          portfolio_id?: string
          sort_order?: number
          suffix?: string
          updated_at?: string
          value?: string
        }
        Relationships: [
          {
            foreignKeyName: "stats_portfolio_id_fkey"
            columns: ["portfolio_id"]
            isOneToOne: false
            referencedRelation: "portfolios"
            referencedColumns: ["id"]
          },
        ]
      }
      user_media: {
        Row: {
          intro_video_path: string | null
          portrait_path: string | null
          poster_path: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          intro_video_path?: string | null
          portrait_path?: string | null
          poster_path?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          intro_video_path?: string | null
          portrait_path?: string | null
          poster_path?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_stats: {
        Row: {
          id: string
          key: string
          label: string
          sort_order: number
          suffix: string
          updated_at: string
          user_id: string
          value: string
        }
        Insert: {
          id?: string
          key: string
          label: string
          sort_order?: number
          suffix?: string
          updated_at?: string
          user_id: string
          value: string
        }
        Update: {
          id?: string
          key?: string
          label?: string
          sort_order?: number
          suffix?: string
          updated_at?: string
          user_id?: string
          value?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_approved_payment: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      owns_portfolio: { Args: { _portfolio_id: string }; Returns: boolean }
      portfolio_is_public: { Args: { _portfolio_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
