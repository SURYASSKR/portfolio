CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  );
$$;

REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO service_role;

DROP POLICY IF EXISTS "Admins can view intro videos" ON storage.objects;
DROP POLICY IF EXISTS "Admins can upload intro videos" ON storage.objects;
DROP POLICY IF EXISTS "Admins can update intro videos" ON storage.objects;
DROP POLICY IF EXISTS "Admins can delete intro videos" ON storage.objects;
DROP POLICY IF EXISTS "Owner writes intro videos" ON storage.objects;
DROP POLICY IF EXISTS "Owner updates intro videos" ON storage.objects;
DROP POLICY IF EXISTS "Owner deletes intro videos" ON storage.objects;

CREATE POLICY "Admins can view intro videos"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'introduction-videos'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "Admins can upload intro videos"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'introduction-videos'
  AND lower(storage.extension(name)) = 'mp4'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "Admins can update intro videos"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'introduction-videos'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
)
WITH CHECK (
  bucket_id = 'introduction-videos'
  AND lower(storage.extension(name)) = 'mp4'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "Admins can delete intro videos"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'introduction-videos'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);

DROP POLICY IF EXISTS "Admins can manage introduction posters" ON storage.objects;
DROP POLICY IF EXISTS "Admins can view introduction posters" ON storage.objects;
DROP POLICY IF EXISTS "Owner writes posters" ON storage.objects;
DROP POLICY IF EXISTS "Owner updates posters" ON storage.objects;
DROP POLICY IF EXISTS "Owner deletes posters" ON storage.objects;

CREATE POLICY "Admins can view introduction posters"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'introduction-posters'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "Admins can upload introduction posters"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'introduction-posters'
  AND lower(storage.extension(name)) IN ('jpg', 'jpeg', 'png', 'webp')
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "Admins can update introduction posters"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'introduction-posters'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
)
WITH CHECK (
  bucket_id = 'introduction-posters'
  AND lower(storage.extension(name)) IN ('jpg', 'jpeg', 'png', 'webp')
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);

CREATE POLICY "Admins can delete introduction posters"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'introduction-posters'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);