
-- Restrict profiles: remove public read; owners and admins only
DROP POLICY IF EXISTS "Profiles are public" ON public.profiles;

CREATE POLICY "Users can view their own profile"
ON public.profiles FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all profiles"
ON public.profiles FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Storage: remove public/anon read policies. App uses signed URLs.
DROP POLICY IF EXISTS "Public can view introduction posters" ON storage.objects;
DROP POLICY IF EXISTS "Public read posters" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can read intro videos" ON storage.objects;
DROP POLICY IF EXISTS "Public read intro videos" ON storage.objects;

-- Keep authenticated SELECT already present for posters; add same for videos so admins can list.
CREATE POLICY "Authenticated users can view intro videos"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'introduction-videos');
