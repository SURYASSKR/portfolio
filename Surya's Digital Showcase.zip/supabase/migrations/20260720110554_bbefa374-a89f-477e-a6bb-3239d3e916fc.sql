
-- 1) Replace always-true INSERT policy on contact_messages with real validation
DROP POLICY IF EXISTS "Anyone can submit contact messages" ON public.contact_messages;
CREATE POLICY "Anyone can submit contact messages"
  ON public.contact_messages
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    char_length(btrim(name)) BETWEEN 1 AND 200
    AND char_length(btrim(email)) BETWEEN 3 AND 254
    AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND char_length(btrim(message)) BETWEEN 1 AND 5000
  );

-- 2) Hide contact_email from public Data API reads via column-level privileges.
--    Server functions use the service role, which bypasses column grants,
--    so admin/portfolio server code continues to read the field.
REVOKE SELECT (contact_email) ON public.site_content FROM anon, authenticated;
