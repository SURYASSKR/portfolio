CREATE TABLE public.site_content (
  id text PRIMARY KEY DEFAULT 'main' CHECK (id = 'main'),
  first_name text NOT NULL DEFAULT 'Surya',
  last_name text NOT NULL DEFAULT 'Kiran',
  opportunity_text text NOT NULL DEFAULT '',
  hero_bio text NOT NULL DEFAULT '',
  contact_email text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_content TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.site_content TO authenticated;
GRANT ALL ON public.site_content TO service_role;
ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read site content" ON public.site_content FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Admins can insert site content" ON public.site_content FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update site content" ON public.site_content FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete site content" ON public.site_content FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER site_content_updated_at BEFORE UPDATE ON public.site_content FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.experience_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period text NOT NULL,
  role text NOT NULL,
  organization text NOT NULL DEFAULT '',
  track text NOT NULL DEFAULT '',
  note text NOT NULL DEFAULT '',
  is_current boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.experience_entries TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.experience_entries TO authenticated;
GRANT ALL ON public.experience_entries TO service_role;
ALTER TABLE public.experience_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read experience" ON public.experience_entries FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Admins can insert experience" ON public.experience_entries FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update experience" ON public.experience_entries FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete experience" ON public.experience_entries FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER experience_entries_updated_at BEFORE UPDATE ON public.experience_entries FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX experience_entries_sort_idx ON public.experience_entries (sort_order, created_at);

CREATE TABLE public.skill_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  items text[] NOT NULL DEFAULT '{}',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.skill_groups TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.skill_groups TO authenticated;
GRANT ALL ON public.skill_groups TO service_role;
ALTER TABLE public.skill_groups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read skills" ON public.skill_groups FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Admins can insert skills" ON public.skill_groups FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update skills" ON public.skill_groups FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete skills" ON public.skill_groups FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER skill_groups_updated_at BEFORE UPDATE ON public.skill_groups FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX skill_groups_sort_idx ON public.skill_groups (sort_order, created_at);

CREATE TABLE public.contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  message text NOT NULL,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE, DELETE ON public.contact_messages TO authenticated;
GRANT ALL ON public.contact_messages TO service_role;
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can read contact messages" ON public.contact_messages FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update contact messages" ON public.contact_messages FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete contact messages" ON public.contact_messages FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE INDEX contact_messages_created_idx ON public.contact_messages (created_at DESC);

INSERT INTO public.site_content (id, first_name, last_name, opportunity_text, hero_bio, contact_email)
VALUES ('main', 'Surya', 'Kiran', 'Open to Business Analyst, Data Analyst, Product Analyst & AI Opportunities', 'Business and AI-focused professional transforming complex problems into actionable insights, data-driven solutions, efficient processes, and AI-powered workflows. I combine business analysis, data analytics, product thinking, automation, and modern AI tools to design practical solutions, build intelligent applications, and help organizations make better decisions.', 'hello@suryakiran.me');

INSERT INTO public.experience_entries (period, role, organization, track, note, is_current, sort_order) VALUES
('2025 — PRESENT', 'Business Analyst Intern', '', 'Experience', 'Applying business analysis, data analytics, product thinking, and AI automation to practical business problems.', true, 1);

INSERT INTO public.skill_groups (title, items, sort_order) VALUES
('Discovery', ARRAY['Requirement Gathering','User Stories','Stakeholder Management','Process Mapping'], 1),
('Data', ARRAY['SQL','Power BI','Excel','DAX'], 2),
('Delivery', ARRAY['Jira','Confluence','Agile','Scrum'], 3),
('AI & Automation', ARRAY['LLM Tooling','RAG','n8n','Zapier','Python'], 4);

REVOKE EXECUTE ON FUNCTION public.enforce_featured_project_limit() FROM PUBLIC;