
CREATE POLICY "Admins can insert resume" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'resume' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update resume" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'resume' AND public.has_role(auth.uid(), 'admin'))
  WITH CHECK (bucket_id = 'resume' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete resume" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'resume' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can read resume" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'resume' AND public.has_role(auth.uid(), 'admin'));
