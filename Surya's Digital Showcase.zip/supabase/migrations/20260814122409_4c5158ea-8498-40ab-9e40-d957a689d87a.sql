CREATE OR REPLACE FUNCTION public.owns_portfolio(_portfolio_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.portfolios p
    WHERE p.id = _portfolio_id AND p.user_id = auth.uid()
  );
$$;

CREATE OR REPLACE FUNCTION public.portfolio_is_public(_portfolio_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.portfolios p
    WHERE p.id = _portfolio_id AND p.published = true
  );
$$;