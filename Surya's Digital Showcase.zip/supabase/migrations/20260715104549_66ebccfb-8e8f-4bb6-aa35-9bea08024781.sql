UPDATE public.stats SET label = 'INTERNSHIP EXPERIENCE', value = '0.9', suffix = 'months' WHERE key = 'experience';
UPDATE public.stats SET value = '3', suffix = '+' WHERE key = 'projects';
UPDATE public.stats SET value = '3' WHERE key = 'industries';