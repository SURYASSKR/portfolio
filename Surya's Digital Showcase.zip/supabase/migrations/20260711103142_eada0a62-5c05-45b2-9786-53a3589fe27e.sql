-- Policies for the introduction-posters storage bucket

-- Allow anonymous visitors to request signed URLs to view the poster
CREATE POLICY "Public can view introduction posters"
ON storage.objects
FOR SELECT
TO anon
USING (bucket_id = 'introduction-posters');

-- Allow signed-in visitors to request signed URLs to view the poster
CREATE POLICY "Authenticated users can view introduction posters"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'introduction-posters');

-- Allow admins to upload, replace, or delete the poster
CREATE POLICY "Admins can manage introduction posters"
ON storage.objects
FOR ALL
TO authenticated
USING (
  bucket_id = 'introduction-posters'
  AND public.has_role(auth.uid(), 'admin')
)
WITH CHECK (
  bucket_id = 'introduction-posters'
  AND public.has_role(auth.uid(), 'admin')
);