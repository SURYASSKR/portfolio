CREATE POLICY "Admins can view introduction videos"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'introduction-videos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can upload introduction videos"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'introduction-videos'
  AND lower(storage.extension(name)) = 'mp4'
  AND public.has_role(auth.uid(), 'admin')
);

CREATE POLICY "Admins can update introduction videos"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'introduction-videos' AND public.has_role(auth.uid(), 'admin'))
WITH CHECK (
  bucket_id = 'introduction-videos'
  AND lower(storage.extension(name)) = 'mp4'
  AND public.has_role(auth.uid(), 'admin')
);

CREATE POLICY "Admins can delete introduction videos"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'introduction-videos' AND public.has_role(auth.uid(), 'admin'));