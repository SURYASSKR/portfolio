
DO $$
DECLARE p RECORD;
BEGIN
  FOR p IN SELECT policyname FROM pg_policies WHERE schemaname='storage' AND tablename='objects'
    AND (policyname ILIKE '%introduction-videos%' OR policyname ILIKE '%introduction-posters%' OR policyname ILIKE '%intro video%' OR policyname ILIKE '%intro poster%')
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON storage.objects', p.policyname);
  END LOOP;
END $$;

CREATE POLICY "public manage introduction-videos"
  ON storage.objects FOR ALL
  USING (bucket_id = 'introduction-videos')
  WITH CHECK (bucket_id = 'introduction-videos');

CREATE POLICY "public manage introduction-posters"
  ON storage.objects FOR ALL
  USING (bucket_id = 'introduction-posters')
  WITH CHECK (bucket_id = 'introduction-posters');
