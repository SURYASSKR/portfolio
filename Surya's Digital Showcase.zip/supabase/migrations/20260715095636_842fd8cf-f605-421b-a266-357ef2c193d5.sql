
-- Storage: intro videos + posters — replace "any authenticated" with "admin only"
DROP POLICY IF EXISTS "Authenticated users can view intro videos" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can view introduction posters" ON storage.objects;

CREATE POLICY "Admins can view intro videos"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'introduction-videos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can view introduction posters"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'introduction-posters' AND public.has_role(auth.uid(), 'admin'));

-- user_media / user_stats: drop any lingering public-read policies (idempotent)
DROP POLICY IF EXISTS "Media rows are public" ON public.user_media;
DROP POLICY IF EXISTS "Stats are public" ON public.user_stats;
