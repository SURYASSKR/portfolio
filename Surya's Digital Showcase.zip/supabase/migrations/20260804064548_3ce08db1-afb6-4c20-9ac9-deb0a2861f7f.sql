-- user_roles: explicit admin-only management (prevents self role escalation)
DROP POLICY IF EXISTS "Admins can insert roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can update roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can delete roles" ON public.user_roles;

CREATE POLICY "Admins can insert roles"
ON public.user_roles FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update roles"
ON public.user_roles FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete roles"
ON public.user_roles FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- user_stats: admin management policies mirroring profiles/user_media
DROP POLICY IF EXISTS "Admins can insert stats rows" ON public.user_stats;
DROP POLICY IF EXISTS "Admins can update stats rows" ON public.user_stats;
DROP POLICY IF EXISTS "Admins can delete stats rows" ON public.user_stats;

CREATE POLICY "Admins can insert stats rows"
ON public.user_stats FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update stats rows"
ON public.user_stats FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete stats rows"
ON public.user_stats FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));