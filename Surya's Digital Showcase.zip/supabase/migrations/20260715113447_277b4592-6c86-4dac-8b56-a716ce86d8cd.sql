
-- Projects table + storage policies
CREATE TABLE public.projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  tagline text NOT NULL DEFAULT '',
  category text NOT NULL,
  problem text NOT NULL DEFAULT '',
  solution text NOT NULL DEFAULT '',
  impact text NOT NULL DEFAULT '',
  cover_path text NOT NULL,
  live_url text NOT NULL DEFAULT '',
  github_url text NOT NULL DEFAULT '',
  case_study_url text NOT NULL DEFAULT '',
  video_url text NOT NULL DEFAULT '',
  technologies text[] NOT NULL DEFAULT '{}',
  metrics text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'completed',
  featured boolean NOT NULL DEFAULT false,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.projects TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.projects TO authenticated;
GRANT ALL ON public.projects TO service_role;

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Projects are viewable by everyone"
  ON public.projects FOR SELECT
  USING (true);

CREATE POLICY "Admins can insert projects"
  ON public.projects FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update projects"
  ON public.projects FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete projects"
  ON public.projects FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER projects_updated_at
  BEFORE UPDATE ON public.projects
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Cap featured at 3
CREATE OR REPLACE FUNCTION public.enforce_featured_project_limit()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.featured = true THEN
    IF (SELECT count(*) FROM public.projects WHERE featured = true AND id <> NEW.id) >= 3 THEN
      RAISE EXCEPTION 'Maximum of 3 featured projects allowed';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER projects_featured_limit
  BEFORE INSERT OR UPDATE ON public.projects
  FOR EACH ROW EXECUTE FUNCTION public.enforce_featured_project_limit();

CREATE INDEX projects_featured_sort_idx ON public.projects (featured DESC, sort_order ASC, created_at DESC);

-- Storage RLS for project-covers bucket (admin write; read via signed URLs from server)
CREATE POLICY "Admins can upload project covers"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'project-covers' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update project covers"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'project-covers' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete project covers"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'project-covers' AND public.has_role(auth.uid(), 'admin'));
