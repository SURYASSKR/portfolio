UPDATE public.stats SET value = '0.9', suffix = 'months' WHERE key = 'experience';
UPDATE public.stats SET value = '4', suffix = '+' WHERE key = 'projects';
UPDATE public.stats SET value = '02' WHERE key = 'industries';