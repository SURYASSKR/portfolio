DROP POLICY IF EXISTS "public manage introduction-videos" ON storage.objects;
DROP POLICY IF EXISTS "public manage introduction-posters" ON storage.objects;