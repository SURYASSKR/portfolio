
DROP POLICY IF EXISTS "Media rows are public" ON public.user_media;
DROP POLICY IF EXISTS "Stats are public" ON public.user_stats;

CREATE POLICY "Users can view their own media"
  ON public.user_media
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all media"
  ON public.user_media
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view their own stats"
  ON public.user_stats
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all stats"
  ON public.user_stats
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
