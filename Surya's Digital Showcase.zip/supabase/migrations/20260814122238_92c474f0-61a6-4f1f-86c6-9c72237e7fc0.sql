-- 1. PORTFOLIOS
CREATE TABLE public.portfolios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  slug text NOT NULL UNIQUE,
  display_name text NOT NULL DEFAULT '',
  template_version text NOT NULL DEFAULT '1.0',
  published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT portfolios_slug_format CHECK (slug ~ '^[a-z0-9]([a-z0-9-]{1,48}[a-z0-9])$'),
  CONSTRAINT portfolios_slug_reserved CHECK (slug NOT IN (
    'admin','auth','api','p','dashboard','login','logout','signup','register',
    'settings','account','static','assets','public','new','create','pricing','about'
  ))
);

GRANT SELECT ON public.portfolios TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.portfolios TO authenticated;
GRANT ALL ON public.portfolios TO service_role;

ALTER TABLE public.portfolios ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Published portfolios are viewable by everyone"
  ON public.portfolios FOR SELECT TO anon, authenticated
  USING (published = true);
CREATE POLICY "Owners can view own portfolio"
  ON public.portfolios FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "Owners can create own portfolio"
  ON public.portfolios FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Owners can update own portfolio"
  ON public.portfolios FOR UPDATE TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Owners can delete own portfolio"
  ON public.portfolios FOR DELETE TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "Platform admins manage portfolios"
  ON public.portfolios FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER portfolios_set_updated_at
  BEFORE UPDATE ON public.portfolios
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 2. HELPERS
CREATE OR REPLACE FUNCTION public.owns_portfolio(_portfolio_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.portfolios p
    WHERE p.id = _portfolio_id AND p.user_id = auth.uid()
  );
$$;

CREATE OR REPLACE FUNCTION public.portfolio_is_public(_portfolio_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.portfolios p
    WHERE p.id = _portfolio_id AND p.published = true
  );
$$;

GRANT EXECUTE ON FUNCTION public.owns_portfolio(uuid) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.portfolio_is_public(uuid) TO anon, authenticated, service_role;

-- 3. SEED OWNER PORTFOLIO
INSERT INTO public.portfolios (user_id, slug, display_name, template_version, published)
VALUES ('6dab679e-8a19-4cf4-9ffd-7e0c8abca1f9', 'surya-kiran', 'Surya Kiran', '1.0', true);

-- 4. SCOPE CONTENT TABLES
ALTER TABLE public.projects           ADD COLUMN portfolio_id uuid REFERENCES public.portfolios(id) ON DELETE CASCADE;
ALTER TABLE public.experience_entries ADD COLUMN portfolio_id uuid REFERENCES public.portfolios(id) ON DELETE CASCADE;
ALTER TABLE public.skill_groups       ADD COLUMN portfolio_id uuid REFERENCES public.portfolios(id) ON DELETE CASCADE;
ALTER TABLE public.stats              ADD COLUMN portfolio_id uuid REFERENCES public.portfolios(id) ON DELETE CASCADE;
ALTER TABLE public.site_content       ADD COLUMN portfolio_id uuid REFERENCES public.portfolios(id) ON DELETE CASCADE;
ALTER TABLE public.contact_messages   ADD COLUMN portfolio_id uuid REFERENCES public.portfolios(id) ON DELETE CASCADE;

UPDATE public.projects           SET portfolio_id = (SELECT id FROM public.portfolios WHERE slug = 'surya-kiran');
UPDATE public.experience_entries SET portfolio_id = (SELECT id FROM public.portfolios WHERE slug = 'surya-kiran');
UPDATE public.skill_groups       SET portfolio_id = (SELECT id FROM public.portfolios WHERE slug = 'surya-kiran');
UPDATE public.stats              SET portfolio_id = (SELECT id FROM public.portfolios WHERE slug = 'surya-kiran');
UPDATE public.site_content       SET portfolio_id = (SELECT id FROM public.portfolios WHERE slug = 'surya-kiran');
UPDATE public.contact_messages   SET portfolio_id = (SELECT id FROM public.portfolios WHERE slug = 'surya-kiran');

ALTER TABLE public.projects           ALTER COLUMN portfolio_id SET NOT NULL;
ALTER TABLE public.experience_entries ALTER COLUMN portfolio_id SET NOT NULL;
ALTER TABLE public.skill_groups       ALTER COLUMN portfolio_id SET NOT NULL;
ALTER TABLE public.stats              ALTER COLUMN portfolio_id SET NOT NULL;
ALTER TABLE public.site_content       ALTER COLUMN portfolio_id SET NOT NULL;

CREATE UNIQUE INDEX site_content_portfolio_id_key ON public.site_content (portfolio_id);
CREATE INDEX projects_portfolio_id_idx ON public.projects (portfolio_id);
CREATE UNIQUE INDEX projects_portfolio_slug_key ON public.projects (portfolio_id, slug);
CREATE INDEX experience_portfolio_id_idx ON public.experience_entries (portfolio_id);
CREATE INDEX skill_groups_portfolio_id_idx ON public.skill_groups (portfolio_id);
CREATE INDEX stats_portfolio_id_idx ON public.stats (portfolio_id);
CREATE INDEX contact_messages_portfolio_id_idx ON public.contact_messages (portfolio_id);

-- 5. REPLACE POLICIES WITH PORTFOLIO-SCOPED ONES
DROP POLICY IF EXISTS "Admins can delete projects" ON public.projects;
DROP POLICY IF EXISTS "Admins can insert projects" ON public.projects;
DROP POLICY IF EXISTS "Admins can update projects" ON public.projects;
DROP POLICY IF EXISTS "Projects are viewable by everyone" ON public.projects;

CREATE POLICY "Public can read projects of published portfolios"
  ON public.projects FOR SELECT TO anon, authenticated
  USING (public.portfolio_is_public(portfolio_id));
CREATE POLICY "Owners manage own projects"
  ON public.projects FOR ALL TO authenticated
  USING (public.owns_portfolio(portfolio_id)) WITH CHECK (public.owns_portfolio(portfolio_id));
CREATE POLICY "Platform admins manage projects"
  ON public.projects FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can delete experience" ON public.experience_entries;
DROP POLICY IF EXISTS "Admins can insert experience" ON public.experience_entries;
DROP POLICY IF EXISTS "Admins can update experience" ON public.experience_entries;
DROP POLICY IF EXISTS "Public can read experience" ON public.experience_entries;

CREATE POLICY "Public can read experience of published portfolios"
  ON public.experience_entries FOR SELECT TO anon, authenticated
  USING (public.portfolio_is_public(portfolio_id));
CREATE POLICY "Owners manage own experience"
  ON public.experience_entries FOR ALL TO authenticated
  USING (public.owns_portfolio(portfolio_id)) WITH CHECK (public.owns_portfolio(portfolio_id));
CREATE POLICY "Platform admins manage experience"
  ON public.experience_entries FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can delete skills" ON public.skill_groups;
DROP POLICY IF EXISTS "Admins can insert skills" ON public.skill_groups;
DROP POLICY IF EXISTS "Admins can update skills" ON public.skill_groups;
DROP POLICY IF EXISTS "Public can read skills" ON public.skill_groups;

CREATE POLICY "Public can read skills of published portfolios"
  ON public.skill_groups FOR SELECT TO anon, authenticated
  USING (public.portfolio_is_public(portfolio_id));
CREATE POLICY "Owners manage own skills"
  ON public.skill_groups FOR ALL TO authenticated
  USING (public.owns_portfolio(portfolio_id)) WITH CHECK (public.owns_portfolio(portfolio_id));
CREATE POLICY "Platform admins manage skills"
  ON public.skill_groups FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can delete stats" ON public.stats;
DROP POLICY IF EXISTS "Admins can insert stats" ON public.stats;
DROP POLICY IF EXISTS "Admins can update stats" ON public.stats;
DROP POLICY IF EXISTS "Anyone can read stats" ON public.stats;

CREATE POLICY "Public can read stats of published portfolios"
  ON public.stats FOR SELECT TO anon, authenticated
  USING (public.portfolio_is_public(portfolio_id));
CREATE POLICY "Owners manage own stats"
  ON public.stats FOR ALL TO authenticated
  USING (public.owns_portfolio(portfolio_id)) WITH CHECK (public.owns_portfolio(portfolio_id));
CREATE POLICY "Platform admins manage stats"
  ON public.stats FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can delete site content" ON public.site_content;
DROP POLICY IF EXISTS "Admins can insert site content" ON public.site_content;
DROP POLICY IF EXISTS "Admins can update site content" ON public.site_content;
DROP POLICY IF EXISTS "Public can read site content" ON public.site_content;

CREATE POLICY "Public can read site content of published portfolios"
  ON public.site_content FOR SELECT TO anon, authenticated
  USING (public.portfolio_is_public(portfolio_id));
CREATE POLICY "Owners manage own site content"
  ON public.site_content FOR ALL TO authenticated
  USING (public.owns_portfolio(portfolio_id)) WITH CHECK (public.owns_portfolio(portfolio_id));
CREATE POLICY "Platform admins manage site content"
  ON public.site_content FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can delete contact messages" ON public.contact_messages;
DROP POLICY IF EXISTS "Admins can read contact messages" ON public.contact_messages;
DROP POLICY IF EXISTS "Admins can update contact messages" ON public.contact_messages;

CREATE POLICY "Owners read own contact messages"
  ON public.contact_messages FOR SELECT TO authenticated
  USING (public.owns_portfolio(portfolio_id));
CREATE POLICY "Owners update own contact messages"
  ON public.contact_messages FOR UPDATE TO authenticated
  USING (public.owns_portfolio(portfolio_id)) WITH CHECK (public.owns_portfolio(portfolio_id));
CREATE POLICY "Owners delete own contact messages"
  ON public.contact_messages FOR DELETE TO authenticated
  USING (public.owns_portfolio(portfolio_id));
CREATE POLICY "Platform admins manage contact messages"
  ON public.contact_messages FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 6. site_content id no longer needs to be 'main'
ALTER TABLE public.site_content ALTER COLUMN id SET DEFAULT gen_random_uuid()::text;