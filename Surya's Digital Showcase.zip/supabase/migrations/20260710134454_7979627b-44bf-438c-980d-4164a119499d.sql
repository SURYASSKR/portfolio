
-- RLS policies for introduction-videos bucket
CREATE POLICY "Anyone can read intro videos"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'introduction-videos');

CREATE POLICY "Admins can upload intro videos"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'introduction-videos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update intro videos"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'introduction-videos' AND public.has_role(auth.uid(), 'admin'))
  WITH CHECK (bucket_id = 'introduction-videos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete intro videos"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'introduction-videos' AND public.has_role(auth.uid(), 'admin'));
