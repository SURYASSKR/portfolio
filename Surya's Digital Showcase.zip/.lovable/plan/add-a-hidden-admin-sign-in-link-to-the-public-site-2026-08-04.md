# Add a hidden Admin sign-in link to the public site

## Goal
Make the admin login easy for the owner to reach without exposing it prominently to visitors.

## Plan
1. Add a small, muted "Admin" link to the footer in `src/routes/index.tsx`, linking to `/auth`.
2. Style it unobtrusively (small, low-contrast text) so it blends into the footer and is not obvious to casual visitors.
3. Keep all existing navigation, colors, typography, and layout unchanged.
4. Verify the link navigates to `/auth` and that the public UI remains clean.

## Files to change
- `src/routes/index.tsx` — footer section
